/*
 * Simple hash-based router.
 * useRoute() -> { path, params, go(path), replace(path) }
 */
function useRoute() {
  const [hash, setHash] = React.useState(() => window.location.hash.slice(1) || '/');
  React.useEffect(() => {
    const onChange = () => setHash(window.location.hash.slice(1) || '/');
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  const [path, query] = hash.split('?');
  const params = Object.fromEntries(new URLSearchParams(query || ''));
  const go = (p) => { window.location.hash = '#' + p; window.scrollTo(0, 0); };
  const replace = (p) => { window.location.replace('#' + p); window.scrollTo(0, 0); };
  return { path, params, go, replace, hash };
}
window.useRoute = useRoute;
