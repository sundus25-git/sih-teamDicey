/*
 * Mock Supabase-shaped client backed by localStorage.
 * The API mirrors a subset of @supabase/supabase-js so it can be swapped later:
 *   db.from('farmers').select()
 *   db.from('farmers').insert({...})
 *   db.from('farmers').update({...}).eq('id', id)
 *   db.from('bookings').select().eq('farmer_id', id)
 *   db.auth.setCurrent(farmerId) / db.auth.getCurrent()
 *
 * All tables live under localStorage key "td.<table>".
 */
(function () {
  const LS_PREFIX = 'td.';

  const uid = (prefix = 'id') =>
    prefix + '_' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);

  const readTable = (name) => {
    try {
      const raw = localStorage.getItem(LS_PREFIX + name);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  };
  const writeTable = (name, rows) => {
    localStorage.setItem(LS_PREFIX + name, JSON.stringify(rows));
    // Notify listeners
    window.dispatchEvent(new CustomEvent('td:table', { detail: { name } }));
  };

  function Query(table) {
    let filters = [];
    let sortBy = null;
    let limitN = null;
    const api = {
      eq(col, val) { filters.push((r) => r[col] === val); return api; },
      neq(col, val) { filters.push((r) => r[col] !== val); return api; },
      in(col, vals) { filters.push((r) => vals.includes(r[col])); return api; },
      order(col, opts = { ascending: true }) { sortBy = { col, asc: opts.ascending !== false }; return api; },
      limit(n) { limitN = n; return api; },
      select() {
        let rows = readTable(table);
        for (const f of filters) rows = rows.filter(f);
        if (sortBy) {
          rows.sort((a, b) => {
            const av = a[sortBy.col], bv = b[sortBy.col];
            if (av === bv) return 0;
            return (av > bv ? 1 : -1) * (sortBy.asc ? 1 : -1);
          });
        }
        if (limitN != null) rows = rows.slice(0, limitN);
        return { data: rows, error: null };
      },
      single() {
        const { data } = api.select();
        return { data: data[0] || null, error: null };
      },
      insert(payload) {
        const rows = readTable(table);
        const rec = { id: payload.id || uid(table.slice(0, 3)), created_at: new Date().toISOString(), ...payload };
        rows.push(rec);
        writeTable(table, rows);
        return { data: rec, error: null };
      },
      update(patch) {
        return {
          eq(col, val) {
            const rows = readTable(table);
            let updated = null;
            for (let i = 0; i < rows.length; i++) {
              if (rows[i][col] === val) {
                rows[i] = { ...rows[i], ...patch, updated_at: new Date().toISOString() };
                updated = rows[i];
              }
            }
            writeTable(table, rows);
            return { data: updated, error: null };
          }
        };
      },
      delete() {
        return {
          eq(col, val) {
            const rows = readTable(table).filter((r) => r[col] !== val);
            writeTable(table, rows);
            return { data: null, error: null };
          }
        };
      },
      upsert(payload, opts = {}) {
        const key = opts.onConflict || 'id';
        const rows = readTable(table);
        const idx = rows.findIndex((r) => r[key] === payload[key]);
        if (idx >= 0) {
          rows[idx] = { ...rows[idx], ...payload, updated_at: new Date().toISOString() };
        } else {
          rows.push({ id: payload.id || uid(table.slice(0, 3)), created_at: new Date().toISOString(), ...payload });
        }
        writeTable(table, rows);
        return { data: payload, error: null };
      }
    };
    return api;
  }

  const auth = {
    setCurrent(farmerId) { localStorage.setItem(LS_PREFIX + 'session', farmerId || ''); window.dispatchEvent(new CustomEvent('td:session')); },
    getCurrent() { return localStorage.getItem(LS_PREFIX + 'session') || null; },
    signOut() { localStorage.removeItem(LS_PREFIX + 'session'); window.dispatchEvent(new CustomEvent('td:session')); }
  };

  const util = {
    uid,
    resetAll() {
      const keys = Object.keys(localStorage).filter((k) => k.startsWith(LS_PREFIX));
      keys.forEach((k) => localStorage.removeItem(k));
      window.dispatchEvent(new CustomEvent('td:reset'));
    },
    subscribe(table, cb) {
      const h = (e) => { if (!table || e.detail?.name === table) cb(); };
      window.addEventListener('td:table', h);
      return () => window.removeEventListener('td:table', h);
    }
  };

  window.db = { from: Query, auth, util };
})();
