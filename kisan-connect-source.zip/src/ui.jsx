/*
 * UI primitives. Every component here is a reusable building block used across pages.
 */
const { useState, useEffect, useMemo, useRef, useCallback, createContext, useContext } = React;

/* ---------- Button ---------- */
function Button({ variant = 'primary', size = 'md', as: As = 'button', className = '', children, ...rest }) {
  const base = 'inline-flex items-center justify-center gap-2 rounded-2xl font-semibold transition-all active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-cream-50';
  const sizes = {
    sm: 'px-3.5 py-2 text-sm',
    md: 'px-5 py-3 text-[15px]',
    lg: 'px-6 py-3.5 text-base',
    xl: 'px-7 py-4 text-lg'
  };
  const variants = {
    primary: 'bg-navy-800 text-white hover:bg-navy-700 shadow-card focus:ring-navy-400',
    leaf: 'bg-leaf-600 text-white hover:bg-leaf-700 shadow-card focus:ring-leaf-400',
    spice: 'bg-spice-500 text-white hover:bg-spice-600 shadow-card focus:ring-spice-400',
    outline: 'bg-white text-navy-800 border border-navy-200 hover:border-navy-400 hover:bg-navy-50 focus:ring-navy-300',
    ghost: 'text-navy-800 hover:bg-navy-50 focus:ring-navy-200',
    quiet: 'bg-cream-100 text-navy-800 hover:bg-cream-200 focus:ring-navy-200'
  };
  return (
    <As className={`${base} ${sizes[size]} ${variants[variant]} ${className}`} {...rest}>
      {children}
    </As>
  );
}

/* ---------- LanguageSwitch ---------- */
/* EN / हिंदी toggle. Persists via i18n.setLang (localStorage) and re-renders any
   component using useLang() anywhere in the app. Shared across every page/header. */
function LanguageSwitch({ lang, setLang, compact = false }) {
  return (
    <div className={`inline-flex items-center rounded-full border border-cream-200 bg-white p-0.5 ${compact ? 'text-[11px]' : 'text-xs'}`}>
      <button
        onClick={() => setLang('en')}
        aria-pressed={lang === 'en'}
        className={`px-2.5 py-1 rounded-full font-semibold transition-colors ${lang === 'en' ? 'bg-navy-800 text-white' : 'text-navy-500 hover:text-navy-800'}`}
      >
        EN
      </button>
      <button
        onClick={() => setLang('hi')}
        aria-pressed={lang === 'hi'}
        className={`px-2.5 py-1 rounded-full font-semibold transition-colors ${lang === 'hi' ? 'bg-navy-800 text-white' : 'text-navy-500 hover:text-navy-800'}`}
      >
        हिं
      </button>
    </div>
  );
}

/* ---------- Card ---------- */
function Card({ className = '', children, as: As = 'div', ...rest }) {
  return <As className={`bg-white rounded-3xl shadow-card border border-cream-200/70 ${className}`} {...rest}>{children}</As>;
}

/* ---------- Badge ---------- */
function Badge({ color = 'navy', className = '', children, dot = false }) {
  const map = {
    navy: 'bg-navy-50 text-navy-800 border-navy-100',
    leaf: 'bg-leaf-50 text-leaf-800 border-leaf-100',
    spice: 'bg-spice-50 text-spice-800 border-spice-100',
    amber: 'bg-amber-50 text-amber-800 border-amber-200',
    red: 'bg-red-50 text-red-700 border-red-100',
    slate: 'bg-slate-100 text-slate-700 border-slate-200'
  };
  const dotColor = {
    navy: 'bg-navy-600', leaf: 'bg-leaf-500', spice: 'bg-spice-500',
    amber: 'bg-amber-500', red: 'bg-red-500', slate: 'bg-slate-500'
  }[color];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${map[color]} ${className}`}>
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColor} pulse-dot`} />}
      {children}
    </span>
  );
}

/* ---------- Input / Field ---------- */
function Field({ label, hint, error, required, children }) {
  return (
    <label className="block">
      <div className="flex items-baseline justify-between mb-1.5">
        <span className="text-sm font-semibold text-navy-800">
          {label}{required && <span className="text-spice-500 ml-0.5">*</span>}
        </span>
        {hint && !error && <span className="text-xs text-navy-400">{hint}</span>}
      </div>
      {children}
      {error && <div className="mt-1.5 text-xs font-medium text-red-600 flex items-center gap-1">
        <Icons.Alert size={13}/>{error}
      </div>}
    </label>
  );
}

function Input({ className = '', invalid, ...rest }) {
  const err = invalid ? 'border-red-300 focus:border-red-500 focus:ring-red-100' : 'border-cream-300 focus:border-navy-500 focus:ring-navy-100';
  return <input className={`w-full px-4 py-3 rounded-2xl bg-white border ${err} focus:ring-4 outline-none text-[15px] text-navy-900 placeholder:text-navy-300 transition ${className}`} {...rest}/>;
}

function Select({ className = '', invalid, children, ...rest }) {
  const err = invalid ? 'border-red-300 focus:border-red-500 focus:ring-red-100' : 'border-cream-300 focus:border-navy-500 focus:ring-navy-100';
  return (
    <div className="relative">
      <select className={`w-full appearance-none px-4 py-3 pr-10 rounded-2xl bg-white border ${err} focus:ring-4 outline-none text-[15px] text-navy-900 transition ${className}`} {...rest}>
        {children}
      </select>
      <Icons.ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 rotate-90 text-navy-400 pointer-events-none" size={16}/>
    </div>
  );
}

function Textarea({ className = '', invalid, ...rest }) {
  const err = invalid ? 'border-red-300' : 'border-cream-300 focus:border-navy-500';
  return <textarea className={`w-full px-4 py-3 rounded-2xl bg-white border ${err} focus:ring-4 focus:ring-navy-100 outline-none text-[15px] text-navy-900 transition ${className}`} {...rest}/>;
}

/* ---------- Stepper ---------- */
function Stepper({ steps, current }) {
  return (
    <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
      {steps.map((s, i) => {
        const done = i < current, active = i === current;
        return (
          <div key={s.key || i} className="flex items-center gap-1 min-w-fit">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap
              ${done ? 'bg-leaf-100 text-leaf-800' : active ? 'bg-navy-800 text-white' : 'bg-cream-100 text-navy-400'}`}>
              {done ? <Icons.Check size={13}/> : <span className={`w-4 h-4 rounded-full grid place-items-center ${active ? 'bg-white/20' : 'bg-navy-100 text-navy-500'} text-[10px]`}>{i + 1}</span>}
              {s.label}
            </div>
            {i < steps.length - 1 && <div className={`w-4 h-px ${done ? 'bg-leaf-300' : 'bg-cream-200'}`}/>}
          </div>
        );
      })}
    </div>
  );
}

/* ---------- Capacity indicator (progress bar) ---------- */
function CapacityBar({ value = 0, label, size = 'md' }) {
  const color = value < 60 ? 'bg-leaf-500' : value < 85 ? 'bg-spice-400' : 'bg-red-500';
  const h = size === 'sm' ? 'h-1.5' : 'h-2.5';
  return (
    <div>
      {label && <div className="flex justify-between text-xs mb-1"><span className="text-navy-500 font-medium">{label}</span><span className="font-semibold text-navy-800">{Math.round(value)}%</span></div>}
      <div className={`w-full ${h} bg-cream-200 rounded-full overflow-hidden`}>
        <div className={`${h} ${color} rounded-full transition-all duration-500`} style={{ width: Math.min(100, value) + '%' }}/>
      </div>
    </div>
  );
}

/* ---------- Hourly bar chart (24h load) ---------- */
function LoadChart({ data = [], highlightHour, height = 88 }) {
  const max = 100;
  return (
    <div className="w-full">
      <div className="flex items-end gap-[3px]" style={{ height }}>
        {data.map((v, h) => {
          const active = h >= 6 && h <= 18;
          const isHi = h === highlightHour;
          const col = v > 85 ? 'bg-red-400' : v > 65 ? 'bg-spice-400' : v > 30 ? 'bg-leaf-400' : 'bg-cream-300';
          return (
            <div key={h} className="flex-1 flex flex-col items-center gap-1 group">
              <div
                className={`w-full rounded-t-md transition-all ${active ? col : 'bg-cream-200'} ${isHi ? 'ring-2 ring-navy-800 ring-offset-1' : ''}`}
                style={{ height: Math.max(4, (v / max) * height) + 'px' }}
                title={`${h}:00 — ${Math.round(v)}%`}
              />
            </div>
          );
        })}
      </div>
      <div className="flex justify-between text-[10px] font-medium text-navy-400 mt-1.5">
        <span>0</span><span>6</span><span>12</span><span>18</span><span>23</span>
      </div>
    </div>
  );
}

/* ---------- Empty state ---------- */
function EmptyState({ icon: I = Icons.Info, title, subtitle, action }) {
  return (
    <div className="text-center py-10 px-6">
      <div className="w-14 h-14 rounded-2xl bg-cream-100 grid place-items-center mx-auto mb-3 text-navy-400"><I size={26}/></div>
      <div className="font-display font-bold text-navy-900 text-lg">{title}</div>
      {subtitle && <div className="text-sm text-navy-500 mt-1 max-w-xs mx-auto">{subtitle}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ---------- Toast ---------- */
const ToastCtx = createContext(null);
function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((t) => {
    const id = Math.random().toString(36).slice(2);
    setItems((cur) => [...cur, { id, ...t }]);
    setTimeout(() => setItems((cur) => cur.filter((x) => x.id !== id)), t.duration || 3800);
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="fixed top-4 right-4 z-[100] flex flex-col gap-2 max-w-sm">
        {items.map((t) => (
          <div key={t.id} className={`slide-in bg-white shadow-pop border border-cream-200 rounded-2xl px-4 py-3 flex items-start gap-3 min-w-[280px]`}>
            <div className={`w-8 h-8 rounded-xl grid place-items-center flex-none ${t.tone === 'error' ? 'bg-red-100 text-red-600' : t.tone === 'warn' ? 'bg-spice-100 text-spice-600' : 'bg-leaf-100 text-leaf-700'}`}>
              {t.tone === 'error' ? <Icons.Alert size={16}/> : t.tone === 'warn' ? <Icons.Bell size={16}/> : <Icons.Check size={16}/>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-navy-900 text-sm">{t.title}</div>
              {t.msg && <div className="text-xs text-navy-500 mt-0.5">{t.msg}</div>}
            </div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
const useToast = () => useContext(ToastCtx);

/* ---------- QR helper ---------- */
function QRCodeSVG({ text, size = 200 }) {
  const svg = useMemo(() => {
    if (!window.qrcode) return '';
    try {
      const q = window.qrcode(0, 'M');
      q.addData(text);
      q.make();
      return q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
    } catch { return ''; }
  }, [text]);
  return <div style={{ width: size, height: size }} className="[&>svg]:w-full [&>svg]:h-full [&_rect]:fill-navy-900" dangerouslySetInnerHTML={{ __html: svg }}/>;
}

/* ---------- Modal ---------- */
function Modal({ open, onClose, title, children, footer }) {
  useEffect(() => {
    if (!open) return;
    const h = (e) => e.key === 'Escape' && onClose?.();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-navy-900/50 backdrop-blur-sm"/>
      <div className="relative bg-white rounded-3xl shadow-pop max-w-md w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between p-5 border-b border-cream-200">
          <div className="font-display font-bold text-navy-900">{title}</div>
          <button onClick={onClose} className="w-9 h-9 grid place-items-center rounded-xl hover:bg-cream-100 text-navy-500"><Icons.X size={18}/></button>
        </div>
        <div className="p-5">{children}</div>
        {footer && <div className="p-5 border-t border-cream-200 bg-cream-50 flex justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

Object.assign(window, {
  Button, Card, Badge, Field, Input, Select, Textarea, Stepper,
  CapacityBar, LoadChart, EmptyState, QRCodeSVG, Modal,
  ToastProvider, useToast
});
