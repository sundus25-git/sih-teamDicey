function App() {
  const { path, go } = useRoute();

  // Root route logic: send authenticated farmers to dashboard by default? No — landing is public.
  const page = React.useMemo(() => {
    if (path === '/' || path === '') return <LandingPage/>;
    if (path.startsWith('/register')) return <RegisterPage/>;
    if (path.startsWith('/dashboard')) return <DashboardPage/>;
    if (path.startsWith('/planning')) return <PlanningPage/>;
    if (path.startsWith('/recommendation')) return <RecommendationPage/>;
    if (path.startsWith('/confirm')) return <ConfirmPage/>;
    if (path.startsWith('/queue')) return <QueuePage/>;
    if (path.startsWith('/procurement')) return <ProcurementPage/>;
    if (path.startsWith('/notifications')) return <NotificationsPage/>;
    if (path.startsWith('/profile')) return <ProfilePage/>;
    return <LandingPage/>;
  }, [path]);

  return (
    <AppProvider>
      <ToastProvider>
        <div key={path} className="fade-up">{page}</div>
      </ToastProvider>
    </AppProvider>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
