function ConfirmPage() {
  const { go, params } = useRoute();
  const { farmer } = useApp();
  const { t } = useLang();
  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const bookingId = params.booking;
  const booking = React.useMemo(() => window.db.from('bookings').eq('id', bookingId).single().data, [bookingId]);

  if (!booking) {
    return (
      <div className="min-h-screen">
        <AppHeader/>
        <div className="max-w-2xl mx-auto px-4 py-16">
          <EmptyState icon={Icons.Info} title={t('confirm.notFoundTitle')} subtitle={t('confirm.notFoundSub')} action={<Button onClick={() => go('/planning')}>{t('confirm.bookNewSlot')}</Button>}/>
        </div>
      </div>
    );
  }

  const mandi = window.db.from('mandis').eq('id', booking.mandi_id).single().data;

  const passUrl = `td://pass/${booking.token}?farmer=${farmer.id}&mandi=${mandi.id}&t=${booking.arrival_time}&d=${booking.arrival_date}`;

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <Badge color="leaf" className="mb-3"><Icons.Check size={12}/> {t('confirm.slotConfirmed')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('confirm.title')}</h1>
            <p className="text-navy-500 mt-2 max-w-lg">{t('confirm.subtitle')}</p>
          </div>
          <Stepper current={3} steps={[
            { label: t('confirm.steps.register') }, { label: t('confirm.steps.plan') }, { label: t('confirm.steps.recommend') }, { label: t('confirm.steps.confirm') }, { label: t('confirm.steps.track') }
          ]}/>
        </div>

        <div className="grid lg:grid-cols-[420px_1fr] gap-5">
          {/* Digital Pass */}
          <Card className="overflow-hidden">
            <div className="bg-navy-800 text-white p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-white/10 grid place-items-center"><Icons.Wheat size={16}/></div>
                  <div>
                    <div className="text-[10px] uppercase tracking-wider text-white/60">{t('confirm.passLabel')}</div>
                    <div className="font-semibold text-sm">{t('brand.name')}</div>
                  </div>
                </div>
                <Badge color="spice" dot>{t('confirm.active')}</Badge>
              </div>
            </div>
            <div className="p-5 md:p-6">
              <div className="text-center">
                <div className="text-[11px] font-semibold text-navy-400 uppercase tracking-wider">{t('confirm.tokenNumber')}</div>
                <div className="font-display font-extrabold text-navy-900 text-4xl mt-1 tracking-widest">{booking.token}</div>
              </div>

              <div className="mt-5 flex justify-center">
                <div className="p-4 bg-white rounded-2xl border border-cream-200">
                  <QRCodeSVG text={passUrl} size={200}/>
                </div>
              </div>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <PassRow icon={Icons.MapPin} label={t('confirm.mandi')} value={mandi.name} sub={mandi.district}/>
                <PassRow icon={Icons.Calendar} label={t('confirm.date')} value={prettyDate(booking.arrival_date)} sub={new Date(booking.arrival_date + 'T00:00:00').getFullYear()}/>
                <PassRow icon={Icons.Clock} label={t('confirm.arrival')} value={booking.arrival_time} sub={t('confirm.arrivalTolerance')}/>
                <PassRow icon={Icons.Package} label={t('confirm.load')} value={`${booking.quantity} ${t('common.qtl')}`} sub={t(`common.crops.${booking.commodity}`)}/>
              </div>

              <div className="mt-5 pt-5 border-t border-dashed border-cream-300 flex items-center justify-between">
                <div>
                  <div className="text-[11px] font-semibold text-navy-400 uppercase tracking-wider">{t('confirm.farmer')}</div>
                  <div className="font-semibold text-navy-900 text-sm">{farmer.name}</div>
                  <div className="text-xs text-navy-500">+91 {farmer.mobile}</div>
                </div>
                <div className="text-right">
                  <div className="text-[11px] font-semibold text-navy-400 uppercase tracking-wider">{t('confirm.predictedWait')}</div>
                  <div className="font-display font-bold text-navy-900">{booking.predicted_wait} {t('common.min')}</div>
                </div>
              </div>
            </div>

            <div className="p-5 border-t border-cream-200 bg-cream-50 flex flex-col sm:flex-row gap-2">
              <Button variant="leaf" className="flex-1" onClick={() => go('/queue?mandi=' + mandi.id)}>
                {t('confirm.viewQueue')} <Icons.ArrowRight size={16}/>
              </Button>
              <Button variant="outline" onClick={() => window.print()}>
                <Icons.QR size={16}/> {t('confirm.savePass')}
              </Button>
            </div>
          </Card>

          {/* Map + Navigation */}
          <Card className="p-5 md:p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('confirm.navigation')}</div>
                <div className="font-display font-bold text-navy-900 mt-1">{t('confirm.routeTo')} {mandi.name}</div>
              </div>
              <div className="flex items-center gap-2 text-xs text-navy-500">
                <Icons.Route size={14}/> {booking.distance_km} {t('common.km')}
              </div>
            </div>

            <div className="rounded-2xl overflow-hidden border border-cream-200 h-[300px] md:h-[380px]">
              <MandiMap farmer={farmer} mandi={mandi}/>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-2">
              <NavStat icon={Icons.Route} label={t('confirm.distance')} value={`${booking.distance_km} ${t('common.km')}`}/>
              <NavStat icon={Icons.Clock} label={t('confirm.driveTime')} value={`~${Math.round(booking.distance_km * 2.2)} ${t('common.min')}`}/>
              <NavStat icon={Icons.Phone} label={t('confirm.mandiHelp')} value={mandi.contact}/>
            </div>

            <div className="mt-5 rounded-2xl bg-navy-50 p-4 flex gap-3">
              <div className="w-9 h-9 rounded-xl bg-navy-800 text-white grid place-items-center flex-none"><Icons.Info size={16}/></div>
              <div className="text-xs text-navy-700">
                <span className="font-semibold text-navy-900">{t('confirm.guidanceTitle')}</span>{' '}
                {t('confirm.guidanceBody')}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function PassRow({ icon: I, label, value, sub }) {
  return (
    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
      <div className="flex items-center gap-1.5 text-navy-500">
        <I size={13}/>
        <span className="text-[10px] font-semibold uppercase tracking-wider">{label}</span>
      </div>
      <div className="font-display font-bold text-navy-900 text-sm mt-1 leading-tight">{value}</div>
      {sub && <div className="text-[11px] text-navy-500 mt-0.5">{sub}</div>}
    </div>
  );
}

function NavStat({ icon: I, label, value }) {
  return (
    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
      <div className="flex items-center gap-1.5 text-navy-500">
        <I size={13}/>
        <span className="text-[10px] font-semibold uppercase tracking-wider">{label}</span>
      </div>
      <div className="font-display font-bold text-navy-900 text-sm mt-1 leading-tight">{value}</div>
    </div>
  );
}

function MandiMap({ farmer, mandi, allMandis, highlightId }) {
  const ref = React.useRef(null);
  const mapRef = React.useRef(null);

  React.useEffect(() => {
    if (!window.L || !ref.current) return;
    if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }

    const farmerLatLng = [farmer.lat || 29.5, farmer.lng || 76.8];
    const mandiLatLng = mandi ? [mandi.lat, mandi.lng] : farmerLatLng;

    const map = window.L.map(ref.current, { zoomControl: true, attributionControl: false });
    mapRef.current = map;
    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18 }).addTo(map);

    const farmerIcon = window.L.divIcon({
      className: 'farmer-marker',
      html: `<div style="background:#0B2545;color:#fff;border-radius:999px;padding:6px 10px;font-size:11px;font-weight:700;box-shadow:0 4px 12px rgba(11,37,69,.3);white-space:nowrap;">You · ${farmer.name?.split(' ')[0] || 'Farmer'}</div>`,
      iconSize: [80, 24], iconAnchor: [40, 12]
    });
    window.L.marker(farmerLatLng, { icon: farmerIcon }).addTo(map);

    // Draw all mandis if provided
    const centres = allMandis || (mandi ? [mandi] : []);
    for (const m of centres) {
      const isHi = m.id === (highlightId || mandi?.id);
      const icon = window.L.divIcon({
        className: 'mandi-marker',
        html: `<div style="background:${isHi ? '#15803D' : '#EA580C'};color:#fff;border-radius:12px;padding:6px 10px;font-size:11px;font-weight:700;box-shadow:0 4px 12px rgba(0,0,0,.2);white-space:nowrap;">🏬 ${m.name.replace(' Mandi','').replace(' APMC','')}</div>`,
        iconSize: [140, 26], iconAnchor: [70, 13]
      });
      window.L.marker([m.lat, m.lng], { icon }).addTo(map);
    }

    if (mandi) {
      // route line (straight for demo)
      window.L.polyline([farmerLatLng, mandiLatLng], { color: '#15803D', weight: 4, opacity: 0.6, dashArray: '8 6' }).addTo(map);
    }

    const bounds = window.L.latLngBounds([farmerLatLng, ...(centres.map(m => [m.lat, m.lng]))]);
    map.fitBounds(bounds, { padding: [40, 40] });

    return () => { map.remove(); mapRef.current = null; };
  }, [farmer.id, mandi?.id, (allMandis || []).map(m => m.id).join(','), highlightId]);

  return <div ref={ref} className="w-full h-full"/>;
}

window.ConfirmPage = ConfirmPage;
window.MandiMap = MandiMap;
