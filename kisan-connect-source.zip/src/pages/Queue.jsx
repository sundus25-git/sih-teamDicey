function QueuePage() {
  const { go, params } = useRoute();
  const { farmer, notify } = useApp();
  const toast = useToast();
  const { t } = useLang();

  const bookings = useTable('bookings', (b) => farmer && b.farmer_id === farmer.id && b.status !== 'completed');
  const activeBooking = bookings.sort((a, b) => a.arrival_date.localeCompare(b.arrival_date))[0];
  const mandiId = params.mandi || activeBooking?.mandi_id;
  const mandi = React.useMemo(() => window.db.from('mandis').eq('id', mandiId).single().data, [mandiId]);

  // Simulated live queue - the farmer's booked position moves down over time.
  // Store simulated data per booking so it persists across renders.
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const iv = setInterval(() => setTick((t) => t + 1), 4000);
    return () => clearInterval(iv);
  }, []);

  const congestion = React.useMemo(() => mandi ? window.ai.detectCongestion(mandi.id) : null, [mandi, tick]);

  // Alt centre if congested
  const altCentre = React.useMemo(() => {
    if (!mandi || !congestion?.congested || !farmer) return null;
    const scored = window.ai.recommend({ ...farmer }, { date: activeBooking?.arrival_date || new Date().toISOString().slice(0, 10), time: activeBooking?.arrival_time || '10:00' });
    return scored.find((s) => s.mandi.id !== mandi.id);
  }, [mandi, congestion, farmer, tick, activeBooking]);

  // Live queue simulation
  const queueState = React.useMemo(() => {
    if (!activeBooking || !mandi) return null;
    const startTs = new Date(activeBooking.created_at).getTime();
    const elapsedMin = Math.max(0, (Date.now() - startTs) / 60000);
    // synthetic farmers ahead: starts at booking's queue position + bumps
    const initialAhead = Math.max(3, Math.min(18, Math.round(activeBooking.predicted_wait / 6)));
    // moves at ~1 person per 3 min per lane
    const movedThrough = Math.min(initialAhead + 5, Math.floor(elapsedMin / 3 * mandi.lanes));
    const ahead = Math.max(0, initialAhead - movedThrough);
    const processing = mandi.avg_processing_min;
    const eta = ahead === 0 ? 0 : Math.max(5, Math.round(ahead / mandi.lanes * processing));
    const state = ahead === 0 ? 'ready' : ahead <= 2 ? 'soon' : 'waiting';
    return { ahead, initialAhead, eta, state, movedThrough };
  }, [activeBooking?.id, mandi?.id, tick]);

  // Reset simulation helper — resets the created_at so demo can be replayed
  const resetSim = () => {
    if (!activeBooking) return;
    window.db.from('bookings').update({ created_at: new Date().toISOString() }).eq('id', activeBooking.id);
    toast.push({ title: t('queue.toastReset'), msg: t('queue.toastResetMsg') });
  };
  const advanceSim = () => {
    if (!activeBooking) return;
    const backdated = new Date(Date.now() - 45 * 60000).toISOString();
    window.db.from('bookings').update({ created_at: backdated }).eq('id', activeBooking.id);
    toast.push({ title: t('queue.toastAdvance'), msg: t('queue.toastAdvanceMsg') });
  };

  const acceptRedirect = () => {
    if (!altCentre || !activeBooking) return;
    window.db.from('bookings').update({ mandi_id: altCentre.mandi.id, predicted_wait: altCentre.wait, distance_km: altCentre.distance }).eq('id', activeBooking.id);
    window.db.from('queue_entries').update({ mandi_id: altCentre.mandi.id }).eq('booking_id', activeBooking.id);
    notify({ type: 'redirect', title: 'Redirected to ' + altCentre.mandi.name, body: `Congestion detected at your original centre. New expected wait: ${altCentre.wait} min.` });
    toast.push({ title: t('queue.toastRedirected'), msg: `${t('confirm.mandi')}: ${altCentre.mandi.name}` });
  };

  const proceedToProcurement = () => {
    // Move procurement record from checkin_pending to checked_in
    if (activeBooking) {
      window.db.from('procurement_records').update({ stage: 'checked_in' }).eq('booking_id', activeBooking.id);
      notify({ type: 'update', title: 'Check-in complete', body: 'You have been checked in. Weighing is next.' });
    }
    go('/procurement');
  };

  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <Badge color="spice" className="mb-3" ><Icons.Zap size={12}/> {t('queue.badge')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('queue.title')}</h1>
            <p className="text-navy-500 mt-2 max-w-lg">{t('queue.subtitle')}</p>
          </div>
          <Stepper current={4} steps={[
            { label: t('queue.steps.register') }, { label: t('queue.steps.plan') }, { label: t('queue.steps.recommend') }, { label: t('queue.steps.confirm') }, { label: t('queue.steps.track') }
          ]}/>
        </div>

        {!activeBooking && (
          <Card className="p-8">
            <EmptyState icon={Icons.Calendar} title={t('queue.noBookingTitle')} subtitle={t('queue.noBookingSub')}
              action={<Button variant="leaf" onClick={() => go('/planning')}>{t('queue.bookSlot')}</Button>}/>
          </Card>
        )}

        {activeBooking && mandi && queueState && (
          <div className="grid lg:grid-cols-[1fr_360px] gap-5">
            {/* Left column */}
            <div className="space-y-5">
              {/* Position hero */}
              <Card className="p-6 relative overflow-hidden">
                <div className={`absolute -right-24 -top-24 w-72 h-72 rounded-full blur-3xl opacity-40
                  ${queueState.state === 'ready' ? 'bg-leaf-200' : queueState.state === 'soon' ? 'bg-spice-200' : 'bg-navy-200'}`}/>
                <div className="relative">
                  <div className="flex items-start justify-between flex-wrap gap-3">
                    <div>
                      <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('queue.yourPositionAt')}</div>
                      <div className="font-display font-bold text-navy-900 text-xl mt-0.5">{mandi.name}</div>
                      <div className="text-sm text-navy-500 flex items-center gap-3 mt-0.5">
                        <span className="flex items-center gap-1"><Icons.MapPin size={12}/> {mandi.district}</span>
                        <span className="flex items-center gap-1"><Icons.QR size={12}/> {activeBooking.token}</span>
                      </div>
                    </div>
                    <Badge color={queueState.state === 'ready' ? 'leaf' : queueState.state === 'soon' ? 'spice' : 'navy'} dot>
                      {queueState.state === 'ready' ? t('queue.readyStatus') : queueState.state === 'soon' ? t('queue.almostStatus') : t('queue.waitingStatus')}
                    </Badge>
                  </div>

                  <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
                    <BigStat label={t('queue.farmersAhead')} value={queueState.ahead} sub={queueState.ahead === 0 ? t('queue.youNext') : t('queue.wasN', { n: queueState.initialAhead })}/>
                    <BigStat label={t('queue.eta')} value={queueState.eta === 0 ? t('queue.now') : `${queueState.eta} ${t('common.min')}`} sub={t('queue.liveEstimate')}/>
                    <BigStat label={t('queue.lanesOpen')} value={mandi.lanes} sub={t('queue.processingLanes')}/>
                    <BigStat label={t('queue.perFarmer')} value={`~${mandi.avg_processing_min}m`} sub={t('queue.avgProcessing')}/>
                  </div>

                  {/* Progress visualisation */}
                  <div className="mt-6">
                    <div className="flex items-center justify-between text-xs text-navy-500 mb-2">
                      <span className="font-semibold text-navy-700">{t('queue.queueProgress')}</span>
                      <span>{queueState.movedThrough} {t('queue.of')} {queueState.initialAhead + queueState.movedThrough} {t('queue.processed')}</span>
                    </div>
                    <div className="flex gap-1">
                      {Array.from({ length: Math.max(queueState.initialAhead + queueState.movedThrough, 12) }).map((_, i) => {
                        const done = i < queueState.movedThrough;
                        const you = i === queueState.movedThrough + queueState.ahead;
                        return (
                          <div key={i} className={`flex-1 h-8 rounded-md ${you ? 'bg-navy-800 ring-2 ring-spice-400' : done ? 'bg-leaf-200' : 'bg-cream-200'}`}>
                            {you && <div className="text-white text-[10px] font-bold text-center leading-8">{t('queue.you')}</div>}
                          </div>
                        );
                      })}
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-navy-400 mt-1.5">
                      <span>{t('queue.gate')}</span><span>{t('queue.weighingShort')}</span>
                    </div>
                  </div>

                  {queueState.state === 'ready' && (
                    <div className="mt-6 rounded-2xl bg-leaf-50 border border-leaf-200 p-4 flex items-center justify-between flex-wrap gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-leaf-600 text-white grid place-items-center"><Icons.Check size={20}/></div>
                        <div>
                          <div className="font-semibold text-leaf-900">{t('queue.readyTitle')}</div>
                          <div className="text-xs text-leaf-800/70">{t('queue.readySub')}</div>
                        </div>
                      </div>
                      <Button variant="leaf" onClick={proceedToProcurement}>{t('queue.proceedCheckin')} <Icons.ArrowRight size={16}/></Button>
                    </div>
                  )}
                </div>
              </Card>

              {/* Congestion alert */}
              {congestion && (
                <Card className={`p-5 ${congestion.congested ? 'border-2 border-spice-300 bg-spice-50/50' : ''}`}>
                  <div className="flex items-start gap-4">
                    <div className={`w-11 h-11 rounded-2xl grid place-items-center flex-none
                      ${congestion.congested ? 'bg-spice-500 text-white' : 'bg-leaf-100 text-leaf-700'}`}>
                      {congestion.congested ? <Icons.Alert size={20}/> : <Icons.Check size={20}/>}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="font-display font-bold text-navy-900">
                          {congestion.congested ? t('queue.congestionDetected') : t('queue.operatingSmoothly')}
                        </div>
                        <Badge color={congestion.congested ? 'spice' : 'leaf'}>{t('queue.level')} {congestion.level}%</Badge>
                      </div>
                      <div className="text-sm text-navy-600 mt-1">{congestion.reason}</div>

                      {congestion.congested && altCentre && (
                        <div className="mt-4 rounded-2xl bg-white border border-cream-200 p-4">
                          <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider mb-1">{t('queue.altCentreTitle')}</div>
                          <div className="flex items-start justify-between gap-4 flex-wrap">
                            <div>
                              <div className="font-display font-bold text-navy-900">{altCentre.mandi.name}</div>
                              <div className="text-xs text-navy-500 flex items-center gap-3 mt-1">
                                <span className="flex items-center gap-1"><Icons.Route size={12}/> {altCentre.distance} {t('common.km')}</span>
                                <span className="flex items-center gap-1"><Icons.Clock size={12}/> {altCentre.wait} {t('queue.waitSuffix')}</span>
                                <span className="flex items-center gap-1"><Icons.BarChart size={12}/> {altCentre.capAvailable}% {t('queue.capacityFree')}</span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button size="sm" variant="ghost" onClick={() => toast.push({ title: t('queue.toastKeeping'), msg: t('queue.toastKeepingMsg') })}>{t('queue.keepCurrent')}</Button>
                              <Button size="sm" variant="leaf" onClick={acceptRedirect}>{t('queue.redirectMe')} <Icons.ArrowRight size={14}/></Button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              )}

              {/* Load chart */}
              <Card className="p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('queue.liveCentreLoad')}</div>
                    <div className="font-display font-bold text-navy-900 mt-0.5">{t('queue.hourlyCongestionToday')}</div>
                  </div>
                  <div className="text-xs text-navy-500 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-leaf-500 pulse-dot"/> {t('queue.updatedLive')}</div>
                </div>
                <LoadChart data={window.ai.predictCentreLoad(mandi.id, activeBooking.arrival_date)} highlightHour={parseInt(activeBooking.arrival_time.split(':')[0], 10)} height={120}/>
                <div className="mt-3 text-xs text-navy-500">
                  <span className="font-semibold text-navy-800">{t('queue.peakHoursToday')}</span> {window.ai.detectPeakHours(mandi).map(h => `${h}:00`).join(', ')}
                </div>
              </Card>
            </div>

            {/* Right column - sidebar */}
            <div className="space-y-5">
              <Card className="p-5">
                <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('queue.booking')}</div>
                <div className="font-display font-bold text-navy-900 text-lg mt-1">{activeBooking.token}</div>
                <div className="mt-3 space-y-2 text-sm">
                  <RowKV k={t('queue.date')} v={prettyDate(activeBooking.arrival_date)}/>
                  <RowKV k={t('queue.slot')} v={activeBooking.arrival_time}/>
                  <RowKV k={t('queue.commodity')} v={t(`common.crops.${activeBooking.commodity}`)}/>
                  <RowKV k={t('queue.quantity')} v={`${activeBooking.quantity} ${t('common.qtl')}`}/>
                  <RowKV k={t('queue.distance')} v={`${activeBooking.distance_km} ${t('common.km')}`}/>
                </div>
                <Button variant="outline" size="sm" className="w-full mt-4" onClick={() => go('/confirm?booking=' + activeBooking.id)}>
                  <Icons.QR size={14}/> {t('queue.viewPass')}
                </Button>
              </Card>

              <Card className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Icons.Cloud size={16} className="text-navy-500"/>
                  <div className="font-display font-bold text-navy-900 text-sm">{t('queue.conditionsToday')}</div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-xl bg-cream-50 p-3">
                    <div className="text-navy-400 text-[10px] uppercase font-semibold">{t('queue.weather')}</div>
                    <div className="font-semibold text-navy-900 mt-1">{t('queue.clearWeather')}</div>
                  </div>
                  <div className="rounded-xl bg-cream-50 p-3">
                    <div className="text-navy-400 text-[10px] uppercase font-semibold">{t('queue.traffic')}</div>
                    <div className="font-semibold text-navy-900 mt-1">{t('queue.lightTraffic')}</div>
                  </div>
                </div>
              </Card>

              <Card className="p-5">
                <div className="font-display font-bold text-navy-900 text-sm mb-3">{t('queue.simulateTitle')}</div>
                <div className="text-xs text-navy-500 mb-3">{t('queue.simulateSub')}</div>
                <div className="flex flex-col gap-2">
                  <Button size="sm" variant="outline" onClick={advanceSim}><Icons.Zap size={14}/> {t('queue.fastForward')}</Button>
                  <Button size="sm" variant="ghost" onClick={resetSim}><Icons.Refresh size={14}/> {t('queue.resetQueue')}</Button>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function BigStat({ label, value, sub }) {
  return (
    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-4">
      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{label}</div>
      <div className="font-display font-extrabold text-navy-900 text-2xl md:text-3xl mt-1">{value}</div>
      {sub && <div className="text-[11px] text-navy-500 mt-0.5">{sub}</div>}
    </div>
  );
}
function RowKV({ k, v }) {
  return <div className="flex justify-between text-sm"><span className="text-navy-500">{k}</span><span className="font-semibold text-navy-900">{v}</span></div>;
}

window.QueuePage = QueuePage;
