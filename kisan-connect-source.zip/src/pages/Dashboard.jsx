function DashboardPage() {
  const { go } = useRoute();
  const { farmer } = useApp();
  const { t } = useLang();
  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const bookings = useTable('bookings', (b) => b.farmer_id === farmer.id);
  const notes = useTable('notifications', (n) => n.farmer_id === farmer.id).sort((a, b) => (b.ts || '').localeCompare(a.ts || ''));
  const records = useTable('procurement_records', (r) => r.farmer_id === farmer.id);

  const upcoming = bookings.filter((b) => b.status !== 'completed').sort((a, b) => a.arrival_date.localeCompare(b.arrival_date));
  const past = bookings.filter((b) => b.status === 'completed').sort((a, b) => b.arrival_date.localeCompare(a.arrival_date));
  const active = upcoming[0];
  const activeMandi = active ? window.db.from('mandis').eq('id', active.mandi_id).single().data : null;
  const activeRecord = active ? records.find((r) => r.booking_id === active.id) : null;
  const activeStage = activeRecord?.stage || 'checkin_pending';
  const stageOrder = ['checkin_pending', 'checked_in', 'weighing', 'quality', 'recorded', 'paid', 'completed'];

  // Live "farmers ahead" preview
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => { const iv = setInterval(() => setTick(t => t + 1), 6000); return () => clearInterval(iv); }, []);
  const ahead = React.useMemo(() => {
    if (!active) return 0;
    const el = (Date.now() - new Date(active.created_at).getTime()) / 60000;
    return Math.max(0, Math.floor((active.predicted_wait / 6) - el / 3 * (activeMandi?.lanes || 4)));
  }, [active?.id, tick]);

  const totalQty = past.reduce((sum, b) => sum + (b.quantity || 0), 0);
  const totalValue = records.filter((r) => r.total_value).reduce((s, r) => s + r.total_value, 0);

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="text-sm text-navy-500">{t('dashboard.namaste')}</div>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{farmer.name.split(' ')[0]} 👋</h1>
            <div className="text-navy-500 text-sm mt-1">{t('dashboard.snapshot')}</div>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => go('/planning')}><Icons.Calendar size={14}/> {t('dashboard.bookNew')}</Button>
            <Button variant="leaf" size="sm" onClick={() => go('/queue')}><Icons.Zap size={14}/> {t('dashboard.liveQueue')}</Button>
          </div>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
          <QuickStat icon={Icons.Calendar} tone="navy" label={t('dashboard.stats.upcoming')} value={upcoming.length} sub={upcoming.length === 0 ? t('dashboard.stats.none') : upcoming.length === 1 ? t('dashboard.stats.slot') : t('dashboard.stats.slots')}/>
          <QuickStat icon={Icons.Package} tone="leaf" label={t('dashboard.stats.completed')} value={past.length} sub={past.length === 1 ? t('dashboard.stats.trip') : t('dashboard.stats.trips')}/>
          <QuickStat icon={Icons.Weight} tone="spice" label={t('dashboard.stats.totalSold')} value={`${totalQty} ${t('common.qtl')}`} sub={t(`common.crops.${farmer.crop}`)}/>
          <QuickStat icon={Icons.IndianRupee} tone="amber" label={t('dashboard.stats.earnings')} value={`₹${(totalValue / 1000).toFixed(1)}k`} sub={t('dashboard.stats.allTime')}/>
        </div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-5 mt-6">
          <div className="space-y-5">
            {/* Active booking hero */}
            {active && activeMandi ? (
              <Card className="p-5 md:p-6 relative overflow-hidden">
                <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-leaf-100 blur-3xl opacity-70"/>
                <div className="relative">
                  <div className="flex items-start justify-between flex-wrap gap-2">
                    <div>
                      <div className="text-xs font-semibold text-leaf-700 uppercase tracking-wider">{t('dashboard.upcomingProcurement')}</div>
                      <div className="font-display font-extrabold text-navy-900 text-2xl md:text-3xl mt-1">{activeMandi.name}</div>
                      <div className="text-sm text-navy-500 flex items-center gap-3 mt-1 flex-wrap">
                        <span className="flex items-center gap-1"><Icons.Calendar size={13}/> {prettyDate(active.arrival_date)}</span>
                        <span className="flex items-center gap-1"><Icons.Clock size={13}/> {active.arrival_time}</span>
                        <span className="flex items-center gap-1"><Icons.Route size={13}/> {active.distance_km} {t('common.km')}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('dashboard.token')}</div>
                      <div className="font-display font-extrabold text-navy-900 text-2xl">{active.token}</div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-5">
                    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3.5">
                      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('dashboard.farmersAhead')}</div>
                      <div className="font-display font-bold text-navy-900 text-xl mt-1">{ahead}</div>
                    </div>
                    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3.5">
                      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('dashboard.eta')}</div>
                      <div className="font-display font-bold text-navy-900 text-xl mt-1">{Math.max(5, ahead * 5)} {t('common.min')}</div>
                    </div>
                    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3.5">
                      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('dashboard.load')}</div>
                      <div className="font-display font-bold text-navy-900 text-xl mt-1">{window.ai.detectCongestion(activeMandi.id).level}%</div>
                    </div>
                    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3.5">
                      <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('dashboard.stage')}</div>
                      <div className="font-display font-bold text-navy-900 text-sm mt-1 leading-tight">{t(`dashboard.stages.${activeStage}`)}</div>
                    </div>
                  </div>

                  {/* Mini stage bar */}
                  <div className="mt-5">
                    <div className="flex items-center justify-between text-xs text-navy-500 mb-2">
                      <span className="font-semibold text-navy-700">{t('dashboard.stagesLabel')}</span>
                      <span>{Math.round((stageOrder.indexOf(activeStage) / (stageOrder.length - 1)) * 100)}%</span>
                    </div>
                    <div className="h-2 bg-cream-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-leaf-500 to-leaf-600" style={{ width: `${(stageOrder.indexOf(activeStage) / (stageOrder.length - 1)) * 100}%` }}/>
                    </div>
                  </div>

                  <div className="mt-5 flex flex-wrap gap-2">
                    <Button size="sm" variant="leaf" onClick={() => go('/queue')}><Icons.Zap size={14}/> {t('dashboard.liveQueue')}</Button>
                    <Button size="sm" variant="outline" onClick={() => go('/confirm?booking=' + active.id)}><Icons.QR size={14}/> {t('dashboard.digitalPass')}</Button>
                    <Button size="sm" variant="outline" onClick={() => go('/procurement')}><Icons.Package size={14}/> {t('dashboard.status')}</Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="p-8">
                <EmptyState icon={Icons.Calendar} title={t('dashboard.noUpcomingTitle')} subtitle={t('dashboard.noUpcomingSub')}
                  action={<Button variant="leaf" onClick={() => go('/planning')}>{t('dashboard.bookFirstSlot')} <Icons.ArrowRight size={14}/></Button>}/>
              </Card>
            )}

            {/* AI Recommended mandi (based on farmer's location) */}
            <RecommendedMandiCard farmer={farmer}/>

            {/* Procurement history */}
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="font-display font-bold text-navy-900">{t('dashboard.history')}</div>
                <Badge color="slate">{past.length} {t('dashboard.completedBadge')}</Badge>
              </div>
              {past.length === 0 ? (
                <div className="text-sm text-navy-500 py-6 text-center">
                  {t('dashboard.noHistory')}
                </div>
              ) : (
                <div className="divide-y divide-cream-200">
                  {past.slice(0, 5).map((b) => {
                    const m = window.db.from('mandis').eq('id', b.mandi_id).single().data;
                    const r = records.find((x) => x.booking_id === b.id);
                    return (
                      <div key={b.id} className="py-3 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <div className="font-semibold text-navy-900 text-sm">{m?.name}</div>
                          <div className="text-xs text-navy-500">{prettyDate(b.arrival_date)} · {b.commodity} · {b.quantity} {t('common.qtl')}</div>
                        </div>
                        <div className="text-right">
                          {r?.total_value && <div className="font-display font-bold text-leaf-700 text-sm">₹{r.total_value.toLocaleString('en-IN')}</div>}
                          <Badge color="leaf" className="mt-0.5">{t('dashboard.completedLabel')}</Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-5">
            <Card className="p-5">
              <div className="flex items-center justify-between mb-3">
                <div className="font-display font-bold text-navy-900 text-sm">{t('dashboard.recentAlerts')}</div>
                <button onClick={() => go('/notifications')} className="text-xs font-semibold text-navy-500 hover:text-navy-800">{t('dashboard.seeAll')}</button>
              </div>
              {notes.length === 0 && <div className="text-xs text-navy-500 py-4 text-center">{t('dashboard.noAlerts')}</div>}
              <div className="space-y-3">
                {notes.slice(0, 4).map((n) => (
                  <div key={n.id} className="flex items-start gap-2.5">
                    <div className={`w-2 h-2 rounded-full mt-1.5 flex-none ${n.read ? 'bg-cream-300' : 'bg-spice-500'}`}/>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold text-navy-900 truncate">{n.title}</div>
                      <div className="text-xs text-navy-500 line-clamp-2">{n.body}</div>
                      <div className="text-[10px] text-navy-400 mt-0.5">{timeAgoShort(n.ts, t)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-5">
              <div className="flex items-center gap-2 mb-2">
                <Icons.User size={16} className="text-navy-500"/>
                <div className="font-display font-bold text-navy-900 text-sm">{t('dashboard.yourProfile')}</div>
              </div>
              <div className="mt-2 space-y-2 text-sm">
                <RowKV k={t('dashboard.crop')} v={t(`common.crops.${farmer.crop}`)}/>
                <RowKV k={t('dashboard.location')} v={farmer.location}/>
                <RowKV k={t('dashboard.mobile')} v={`+91 ${farmer.mobile}`}/>
              </div>
              <Button variant="outline" size="sm" className="w-full mt-4" onClick={() => go('/profile')}>{t('dashboard.editProfile')}</Button>
            </Card>

            <Card className="p-5 bg-gradient-to-br from-navy-800 to-navy-900 text-white border-navy-800">
              <div className="flex items-center gap-2 mb-2">
                <Icons.Sparkles size={16} className="text-spice-300"/>
                <div className="font-display font-bold text-sm">{t('dashboard.tipTitle')}</div>
              </div>
              <div className="text-sm text-white/80 leading-relaxed">
                {t('dashboard.tipBody')}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

function QuickStat({ icon: I, label, value, sub, tone }) {
  const bg = { navy: 'bg-navy-100 text-navy-700', leaf: 'bg-leaf-100 text-leaf-700', spice: 'bg-spice-100 text-spice-700', amber: 'bg-amber-100 text-amber-700' }[tone];
  return (
    <Card className="p-4">
      <div className={`w-9 h-9 rounded-xl grid place-items-center mb-2 ${bg}`}><I size={18}/></div>
      <div className="font-display font-extrabold text-navy-900 text-xl">{value}</div>
      <div className="text-xs text-navy-500 mt-0.5"><span className="font-semibold text-navy-700">{label}</span> · {sub}</div>
    </Card>
  );
}

function RecommendedMandiCard({ farmer }) {
  const { go } = useRoute();
  const { t } = useLang();
  const rec = React.useMemo(() => window.ai.recommend(farmer, { date: new Date(Date.now() + 86400000).toISOString().slice(0, 10), time: '10:00' })[0], [farmer]);
  if (!rec) return null;
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icons.Sparkles size={16} className="text-spice-600"/>
          <div className="font-display font-bold text-navy-900">{t('dashboard.recommendedTomorrow')}</div>
        </div>
        <Badge color="leaf" dot>AI {rec.score}</Badge>
      </div>
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <div className="font-display font-bold text-navy-900">{rec.mandi.name}</div>
          <div className="text-xs text-navy-500 flex items-center gap-3 mt-1">
            <span className="flex items-center gap-1"><Icons.Route size={12}/> {rec.distance} {t('common.km')}</span>
            <span className="flex items-center gap-1"><Icons.Clock size={12}/> {rec.wait} {t('dashboard.waitSuffix')}</span>
          </div>
        </div>
        <Button size="sm" variant="leaf" onClick={() => go('/planning')}>{t('dashboard.bookSlot')} <Icons.ArrowRight size={14}/></Button>
      </div>
    </Card>
  );
}

function timeAgoShort(iso, t) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return t ? t('dashboard.timeAgo.now') : 'now';
  if (min < 60) return min + 'm';
  const h = Math.round(min / 60);
  if (h < 24) return h + 'h';
  return Math.round(h / 24) + 'd';
}

window.DashboardPage = DashboardPage;
