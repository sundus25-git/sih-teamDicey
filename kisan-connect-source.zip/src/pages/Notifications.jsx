function NotificationsPage() {
  const { go } = useRoute();
  const { farmer } = useApp();
  const { t } = useLang();
  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const notes = useTable('notifications', (n) => n.farmer_id === farmer.id).sort((a, b) => (b.ts || '').localeCompare(a.ts || ''));

  const iconFor = {
    welcome: { i: Icons.Sparkles, c: 'leaf' },
    booking: { i: Icons.Calendar, c: 'navy' },
    reminder: { i: Icons.Bell, c: 'spice' },
    redirect: { i: Icons.Route, c: 'amber' },
    update: { i: Icons.Info, c: 'navy' },
    payment: { i: Icons.Wallet, c: 'leaf' },
    complete: { i: Icons.Check, c: 'leaf' },
    delay: { i: Icons.Alert, c: 'red' },
    congestion: { i: Icons.Alert, c: 'spice' }
  };

  const markAllRead = () => {
    notes.forEach((n) => window.db.from('notifications').update({ read: true }).eq('id', n.id));
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-3xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <Badge color="spice" className="mb-3">{t('notifications.badge')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('notifications.title')}</h1>
            <p className="text-navy-500 mt-2">{t('notifications.subtitle')}</p>
          </div>
          {notes.some((n) => !n.read) && (
            <Button size="sm" variant="outline" onClick={markAllRead}><Icons.Check size={14}/> {t('notifications.markAllRead')}</Button>
          )}
        </div>

        {notes.length === 0 && (
          <Card className="p-8">
            <EmptyState icon={Icons.Bell} title={t('notifications.noneTitle')} subtitle={t('notifications.noneSub')}/>
          </Card>
        )}

        <div className="space-y-2">
          {notes.map((n) => {
            const cfg = iconFor[n.type] || iconFor.update;
            return (
              <Card key={n.id} className={`p-4 flex items-start gap-3 ${!n.read ? 'ring-1 ring-navy-200' : ''}`}>
                <div className={`w-11 h-11 rounded-2xl grid place-items-center flex-none
                  ${cfg.c === 'leaf' ? 'bg-leaf-100 text-leaf-700' :
                    cfg.c === 'spice' ? 'bg-spice-100 text-spice-700' :
                    cfg.c === 'amber' ? 'bg-amber-100 text-amber-700' :
                    cfg.c === 'red' ? 'bg-red-100 text-red-700' :
                    'bg-navy-100 text-navy-700'}`}>
                  <cfg.i size={20}/>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2 flex-wrap">
                    <div className="font-semibold text-navy-900">{n.title}</div>
                    {!n.read && <span className="w-1.5 h-1.5 rounded-full bg-spice-500"/>}
                  </div>
                  <div className="text-sm text-navy-600 mt-0.5 leading-relaxed">{n.body}</div>
                  <div className="text-[11px] text-navy-400 mt-1.5">{timeAgo(n.ts, t)}</div>
                </div>
                {!n.read && (
                  <button onClick={() => window.db.from('notifications').update({ read: true }).eq('id', n.id)}
                    className="text-xs font-semibold text-navy-500 hover:text-navy-800 px-2 py-1 rounded-lg hover:bg-cream-100">{t('notifications.markRead')}</button>
                )}
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function timeAgo(iso, t) {
  const tr = t || window.i18n.t;
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.round(diff / 60000);
  if (min < 1) return tr('notifications.timeAgo.justNow');
  if (min < 60) return tr('notifications.timeAgo.minAgo', { n: min });
  const hr = Math.round(min / 60);
  if (hr < 24) return tr('notifications.timeAgo.hrAgo', { n: hr });
  const d = Math.round(hr / 24);
  return tr(d > 1 ? 'notifications.timeAgo.daysAgo' : 'notifications.timeAgo.dayAgo', { n: d });
}

window.NotificationsPage = NotificationsPage;
