function PlanningPage() {
  const { go } = useRoute();
  const { farmer } = useApp();
  const { t } = useLang();

  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const mandis = useTable('mandis');
  const today = new Date();
  const toISO = (d) => d.toISOString().slice(0, 10);
  const [form, setForm] = React.useState({
    date: toISO(new Date(today.getTime() + 86400000)),
    time: '09:00',
    quantity: String(farmer.quantity || 30),
    preferredMandi: '' // '' = auto (AI recommend)
  });

  const [filterCrop, setFilterCrop] = React.useState(farmer.crop || 'Wheat');

  const scored = React.useMemo(() => {
    if (!farmer) return [];
    const list = window.ai.recommend(
      { ...farmer, quantity: parseFloat(form.quantity) || farmer.quantity },
      { date: form.date, time: form.time }
    );
    return list;
  }, [farmer, form.date, form.time, form.quantity]);

  const filtered = scored.filter((s) => filterCrop === 'All' || s.mandi.commodities.includes(filterCrop));

  const availableTimes = [];
  for (let h = 6; h <= 17; h++) {
    for (let m of [0, 30]) {
      availableTimes.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }

  const goToRec = () => {
    const q = { date: form.date, time: form.time, qty: form.quantity };
    if (form.preferredMandi) q.mandi = form.preferredMandi;
    const qs = new URLSearchParams(q).toString();
    go('/recommendation?' + qs);
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <button onClick={() => go('/dashboard')} className="text-sm text-navy-500 hover:text-navy-800 flex items-center gap-1 mb-4"><Icons.ArrowLeft size={14}/> {t('planning.backDashboard')}</button>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <Badge color="navy" className="mb-3">{t('planning.badge')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('planning.title')}</h1>
            <p className="text-navy-500 mt-2 max-w-xl">{t('planning.subtitle')}</p>
          </div>
          <Stepper current={1} steps={[
            { label: t('planning.steps.register') }, { label: t('planning.steps.plan') }, { label: t('planning.steps.recommend') }, { label: t('planning.steps.confirm') }, { label: t('planning.steps.track') }
          ]}/>
        </div>

        <div className="grid lg:grid-cols-[380px_1fr] gap-6 mt-8">
          {/* Left: form */}
          <Card className="p-5 md:p-6 h-fit lg:sticky lg:top-24">
            <div className="font-display font-bold text-navy-900 text-lg">{t('planning.visitDetails')}</div>
            <div className="text-xs text-navy-500 mt-1">{t('planning.visitDetailsSub')}</div>

            <div className="mt-5 space-y-4">
              <Field label={t('planning.arrivalDate')} required>
                <div className="relative">
                  <Input type="date" value={form.date} onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} min={toISO(today)} max={toISO(new Date(today.getTime() + 14 * 86400000))} className="!pl-11"/>
                  <Icons.Calendar size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400"/>
                </div>
              </Field>

              <Field label={t('planning.timeSlot')} required>
                <div className="relative">
                  <Select value={form.time} onChange={(e) => setForm((f) => ({ ...f, time: e.target.value }))} className="!pl-11">
                    {availableTimes.map((tm) => <option key={tm} value={tm}>{tm}</option>)}
                  </Select>
                  <Icons.Clock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-400 z-10"/>
                </div>
              </Field>

              <Field label={t('planning.expectedQty')} required hint={t('common.qtl')}>
                <div className="relative">
                  <Input value={form.quantity} onChange={(e) => setForm((f) => ({ ...f, quantity: e.target.value }))} inputMode="decimal"/>
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-navy-400 text-sm font-medium">{t('common.qtl')}</span>
                </div>
              </Field>

              <Field label={t('planning.preferredCentre')} hint={t('planning.preferredCentreHint')}>
                <Select value={form.preferredMandi} onChange={(e) => setForm((f) => ({ ...f, preferredMandi: e.target.value }))}>
                  <option value="">{t('planning.letAiRecommend')}</option>
                  {mandis.map((m) => <option key={m.id} value={m.id}>{m.name} · {m.district}</option>)}
                </Select>
              </Field>
            </div>

            <Button variant="leaf" className="w-full mt-6" onClick={goToRec}>
              {t('planning.getRecommendation')} <Icons.Sparkles size={16}/>
            </Button>
            <div className="text-[11px] text-navy-400 mt-2 text-center">{t('planning.usesLive')}</div>
          </Card>

          {/* Right: mandi cards */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-sm font-semibold text-navy-800">{t('planning.availableCentres')}</div>
                <div className="text-xs text-navy-500">{filtered.length} {t('planning.matchCount')}</div>
              </div>
              <div className="flex items-center gap-2">
                <Icons.Filter size={14} className="text-navy-400"/>
                <select value={filterCrop} onChange={(e) => setFilterCrop(e.target.value)} className="text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-white border border-cream-300 text-navy-700 outline-none focus:border-navy-500">
                  <option value="All">{t('common.crops.All')}</option>
                  {['Wheat','Paddy','Mustard','Sugarcane','Bajra','Cotton','Vegetables'].map((c) => <option key={c} value={c}>{t(`common.crops.${c}`)}</option>)}
                </select>
              </div>
            </div>

            <div className="grid gap-3">
              {filtered.length === 0 && (
                <Card className="p-8">
                  <EmptyState icon={Icons.Info} title={t('planning.noMatchTitle')} subtitle={t('planning.noMatchSub')}/>
                </Card>
              )}
              {filtered.map((s, i) => <MandiCard key={s.mandi.id} scored={s} rank={i} onSelect={() => {
                const qs = new URLSearchParams({ date: form.date, time: form.time, qty: form.quantity, mandi: s.mandi.id }).toString();
                go('/recommendation?' + qs);
              }}/>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MandiCard({ scored, rank, onSelect }) {
  const { t } = useLang();
  const { mandi, score, distance, wait, congestion, capAvailable } = scored;
  const loadColor = congestion < 60 ? 'leaf' : congestion < 85 ? 'spice' : 'red';
  const isTop = rank === 0;

  return (
    <Card className={`p-5 relative overflow-hidden ${isTop ? 'ring-2 ring-leaf-300' : ''}`}>
      {isTop && (
        <div className="absolute top-0 right-6 bg-leaf-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-b-lg">
          {t('planning.topPick')}
        </div>
      )}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="min-w-0">
          <div className="font-display font-bold text-navy-900 text-lg leading-tight">{mandi.name}</div>
          <div className="text-sm text-navy-500 flex items-center gap-3 mt-1 flex-wrap">
            <span className="flex items-center gap-1"><Icons.MapPin size={13}/> {mandi.district}, {mandi.state}</span>
            <span className="flex items-center gap-1"><Icons.Route size={13}/> {distance} {t('common.km')}</span>
            <span className="flex items-center gap-1"><Icons.Clock size={13}/> {mandi.hours}</span>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {mandi.commodities.map((c) => (
              <span key={c} className="text-[11px] font-medium px-2 py-0.5 rounded-full bg-cream-100 text-navy-600">{t(`common.crops.${c}`)}</span>
            ))}
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('planning.aiMatch')}</div>
          <div className={`font-display font-extrabold text-2xl ${score >= 75 ? 'text-leaf-600' : score >= 55 ? 'text-spice-600' : 'text-navy-500'}`}>{score}</div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mt-4">
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('planning.estWait')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-0.5">{wait} <span className="text-sm text-navy-500">{t('common.min')}</span></div>
        </div>
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('planning.currentLoad')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-0.5">{congestion}%</div>
        </div>
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('planning.available')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-0.5">{capAvailable}%</div>
        </div>
      </div>

      <div className="mt-4">
        <CapacityBar value={congestion} label={t('planning.capacityUsed')} size="sm"/>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <div className="text-xs text-navy-500 flex items-center gap-2">
          <span className={`w-1.5 h-1.5 rounded-full ${loadColor === 'leaf' ? 'bg-leaf-500' : loadColor === 'spice' ? 'bg-spice-500' : 'bg-red-500'}`}/>
          {loadColor === 'leaf' ? t('planning.smooth') : loadColor === 'spice' ? t('planning.moderate') : t('planning.heavy')}
        </div>
        <Button size="sm" variant={isTop ? 'leaf' : 'outline'} onClick={onSelect}>
          {isTop ? t('planning.viewRecommendation') : t('planning.selectCentre')} <Icons.ArrowRight size={14}/>
        </Button>
      </div>
    </Card>
  );
}

window.PlanningPage = PlanningPage;
