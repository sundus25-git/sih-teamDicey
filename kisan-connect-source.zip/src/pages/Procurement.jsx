function ProcurementPage() {
  const { go } = useRoute();
  const { farmer, notify } = useApp();
  const toast = useToast();
  const { t } = useLang();
  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const records = useTable('procurement_records', (r) => r.farmer_id === farmer.id);
  const bookings = useTable('bookings', (b) => b.farmer_id === farmer.id);
  const activeRecord = records.find((r) => r.stage !== 'completed') || records[records.length - 1];
  const [selectedId, setSelectedId] = React.useState(() => activeRecord?.id);
  React.useEffect(() => { if (!selectedId && activeRecord) setSelectedId(activeRecord.id); }, [activeRecord?.id]);

  const record = records.find((r) => r.id === selectedId) || activeRecord;
  const booking = record ? bookings.find((b) => b.id === record.booking_id) : null;
  const mandi = record ? window.db.from('mandis').eq('id', record.mandi_id).single().data : null;

  const stages = [
    { key: 'checkin_pending', label: t('procurement.stages.checkin_pending'), icon: Icons.Clock },
    { key: 'checked_in', label: t('procurement.stages.checked_in'), icon: Icons.Check },
    { key: 'weighing', label: t('procurement.stages.weighing'), icon: Icons.Weight },
    { key: 'quality', label: t('procurement.stages.quality'), icon: Icons.Shield },
    { key: 'recorded', label: t('procurement.stages.recorded'), icon: Icons.Package },
    { key: 'paid', label: t('procurement.stages.paid'), icon: Icons.IndianRupee },
    { key: 'completed', label: t('procurement.stages.completed'), icon: Icons.Check }
  ];
  const stageOrder = ['checkin_pending', 'checked_in', 'weighing', 'quality', 'recorded', 'paid', 'completed'];
  const currentIdx = record ? stageOrder.indexOf(record.stage) : 0;

  const advance = () => {
    if (!record) return;
    const next = stageOrder[Math.min(currentIdx + 1, stageOrder.length - 1)];
    const patch = { stage: next };
    if (next === 'weighing') patch.weighed_qty = record.quantity;
    if (next === 'quality') patch.quality_grade = 'FAQ (Fair Average Quality)';
    if (next === 'recorded') { patch.mandi_price = 2275; patch.total_value = Math.round(record.quantity * 2275); }
    if (next === 'paid') { patch.payment_status = 'paid'; patch.payment_ref = 'UPI/' + Math.random().toString(36).slice(2, 8).toUpperCase(); }
    window.db.from('procurement_records').update(patch).eq('id', record.id);

    // Booking completion
    if (next === 'completed' && booking) {
      window.db.from('bookings').update({ status: 'completed' }).eq('id', booking.id);
      window.db.from('queue_entries').update({ status: 'completed' }).eq('booking_id', booking.id);
      notify({ type: 'complete', title: 'Procurement completed', body: `₹${(record.total_value || 0).toLocaleString('en-IN')} released for ${record.quantity} qtl ${record.commodity} at ${mandi?.name}.` });
    } else if (next === 'paid') {
      notify({ type: 'payment', title: 'Payment released', body: `₹${(Math.round(record.quantity * 2275)).toLocaleString('en-IN')} credited via UPI. Reference: ${patch.payment_ref}` });
    } else if (next === 'weighing') {
      notify({ type: 'update', title: 'Weighing in progress', body: `Your ${record.commodity} is being weighed at Lane 1.` });
    } else if (next === 'quality') {
      notify({ type: 'update', title: 'Quality check', body: `Sample being graded per FAQ standards.` });
    } else if (next === 'recorded') {
      notify({ type: 'update', title: 'Purchase recorded', body: `Rate confirmed at MSP ₹2,275/qtl.` });
    }
    toast.push({ title: stages[stageOrder.indexOf(next)].label });
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-5xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <Badge color="navy" className="mb-3">{t('procurement.badge')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('procurement.title')}</h1>
            <p className="text-navy-500 mt-2 max-w-lg">{t('procurement.subtitle')}</p>
          </div>
          {records.length > 1 && (
            <div>
              <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider mb-1">{t('procurement.historyLabel')}</div>
              <Select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="!py-2">
                {records.map((r) => {
                  const b = bookings.find((x) => x.id === r.booking_id);
                  return <option key={r.id} value={r.id}>{b?.token || 'Record'} · {t(`common.crops.${r.commodity}`)} · {t(`procurement.stages.${r.stage}`)}</option>;
                })}
              </Select>
            </div>
          )}
        </div>

        {!record && (
          <Card className="p-8">
            <EmptyState icon={Icons.Package} title={t('procurement.noRecordsTitle')} subtitle={t('procurement.noRecordsSub')}
              action={<Button variant="leaf" onClick={() => go('/planning')}>{t('procurement.bookSlot')}</Button>}/>
          </Card>
        )}

        {record && mandi && (
          <div className="grid lg:grid-cols-[1fr_360px] gap-5">
            <div className="space-y-5">
              {/* Header card */}
              <Card className="p-5 md:p-6">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div>
                    <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('procurement.at')}</div>
                    <div className="font-display font-bold text-navy-900 text-xl">{mandi.name}</div>
                    <div className="text-sm text-navy-500">{mandi.district}, {mandi.state}</div>
                  </div>
                  <Badge color={record.stage === 'completed' ? 'leaf' : 'spice'} dot>
                    {record.stage === 'completed' ? t('procurement.completed') : stages[currentIdx]?.label || t('procurement.inProgress')}
                  </Badge>
                </div>

                {/* Progress bar */}
                <div className="mt-6">
                  <div className="flex items-center justify-between text-xs text-navy-500 mb-2">
                    <span className="font-semibold">{t('procurement.progress')}</span>
                    <span>{Math.round((currentIdx / (stageOrder.length - 1)) * 100)}% {t('procurement.percentComplete')}</span>
                  </div>
                  <div className="h-2 bg-cream-200 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-leaf-500 to-leaf-600 transition-all duration-700" style={{ width: `${(currentIdx / (stageOrder.length - 1)) * 100}%` }}/>
                  </div>
                </div>

                {/* Stage list */}
                <div className="mt-6 space-y-2">
                  {stages.slice(0, -1).map((s, i) => {
                    const isDone = i < currentIdx;
                    const isActive = i === currentIdx;
                    return (
                      <div key={s.key} className={`flex items-center gap-3 p-3 rounded-2xl border transition
                        ${isActive ? 'border-navy-800 bg-navy-50' : isDone ? 'border-leaf-200 bg-leaf-50' : 'border-cream-200 bg-white'}`}>
                        <div className={`w-10 h-10 rounded-xl grid place-items-center flex-none
                          ${isActive ? 'bg-navy-800 text-white' : isDone ? 'bg-leaf-500 text-white' : 'bg-cream-100 text-navy-400'}`}>
                          {isDone ? <Icons.Check size={18}/> : <s.icon size={18}/>}
                        </div>
                        <div className="flex-1">
                          <div className={`font-semibold text-sm ${isActive ? 'text-navy-900' : isDone ? 'text-leaf-800' : 'text-navy-400'}`}>{s.label}</div>
                          <div className="text-xs text-navy-500">{stageDescription(s.key, record, t)}</div>
                        </div>
                        {isActive && <Badge color="navy" dot>{t('procurement.inProgress')}</Badge>}
                        {isDone && <Icons.Check size={16} className="text-leaf-600"/>}
                      </div>
                    );
                  })}
                </div>

                {record.stage !== 'completed' && (
                  <div className="mt-6 flex flex-col sm:flex-row gap-2 justify-between items-center rounded-2xl bg-cream-50 p-4">
                    <div className="text-xs text-navy-600">
                      <span className="font-semibold text-navy-800">{t('procurement.demoControl')}</span> {t('procurement.demoControlBody')}
                    </div>
                    <Button size="sm" variant="leaf" onClick={advance}>
                      {t('procurement.advanceTo')} {stages[Math.min(currentIdx + 1, stages.length - 1)].label} <Icons.ArrowRight size={14}/>
                    </Button>
                  </div>
                )}

                {record.stage === 'completed' && (
                  <div className="mt-6 rounded-2xl bg-leaf-50 border border-leaf-200 p-4 flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-leaf-600 text-white grid place-items-center"><Icons.Check size={22}/></div>
                    <div className="flex-1">
                      <div className="font-display font-bold text-leaf-900">{t('procurement.completedTitle')}</div>
                      <div className="text-xs text-leaf-800/70">{t('procurement.releasedFor', { amount: '₹' + (record.total_value || 0).toLocaleString('en-IN'), qty: record.quantity, qtl: t('common.qtl'), crop: t(`common.crops.${record.commodity}`) })}</div>
                    </div>
                    <Button size="sm" variant="leaf" onClick={() => go('/planning')}>{t('procurement.newBooking')}</Button>
                  </div>
                )}
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-5">
              <Card className="p-5">
                <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('procurement.summary')}</div>
                <div className="mt-3 space-y-2 text-sm">
                  <RowKV k={t('procurement.token')} v={booking?.token || '—'}/>
                  <RowKV k={t('procurement.commodity')} v={t(`common.crops.${record.commodity}`)}/>
                  <RowKV k={t('procurement.bookedQty')} v={`${record.quantity} ${t('common.qtl')}`}/>
                  {record.weighed_qty != null && <RowKV k={t('procurement.weighed')} v={`${record.weighed_qty} ${t('common.qtl')}`}/>}
                  {record.quality_grade && <RowKV k={t('procurement.grade')} v={record.quality_grade}/>}
                  {record.mandi_price && <RowKV k={t('procurement.rate')} v={`₹${record.mandi_price}/${t('common.qtl')}`}/>}
                  {record.total_value && <RowKV k={t('procurement.totalValue')} v={`₹${record.total_value.toLocaleString('en-IN')}`}/>}
                </div>
              </Card>

              <Card className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Icons.Wallet size={16} className="text-navy-500"/>
                  <div className="font-display font-bold text-navy-900 text-sm">{t('procurement.payment')}</div>
                </div>
                <Badge color={record.payment_status === 'paid' ? 'leaf' : 'amber'} dot>
                  {record.payment_status === 'paid' ? t('procurement.released') : t('procurement.pendingRelease')}
                </Badge>
                {record.payment_ref && (
                  <div className="mt-3 text-xs">
                    <div className="text-navy-500">{t('procurement.reference')}</div>
                    <div className="font-mono font-semibold text-navy-900">{record.payment_ref}</div>
                  </div>
                )}
                {record.payment_status === 'paid' && (
                  <div className="mt-3 text-xs text-navy-600">{t('procurement.dbtNote', { mobile: farmer.mobile })}</div>
                )}
              </Card>

              <Card className="p-5">
                <div className="font-display font-bold text-navy-900 text-sm mb-2">{t('procurement.needHelp')}</div>
                <div className="text-xs text-navy-500 mb-3">{t('procurement.needHelpSub')}</div>
                <div className="space-y-2">
                  <a href={`tel:${mandi.contact.replace(/\s/g, '')}`} className="flex items-center gap-2 text-sm text-navy-800 font-semibold hover:text-navy-600">
                    <Icons.Phone size={14}/> {mandi.contact}
                  </a>
                  <a href="tel:18001802020" className="flex items-center gap-2 text-sm text-navy-800 font-semibold hover:text-navy-600">
                    <Icons.Phone size={14}/> {t('procurement.helpline')}
                  </a>
                </div>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function stageDescription(key, record, t) {
  const tr = t || window.i18n.t;
  switch (key) {
    case 'checkin_pending': return tr('procurement.stageDesc.checkin_pending');
    case 'checked_in': return tr('procurement.stageDesc.checked_in');
    case 'weighing': return `${tr('procurement.stageDesc.weighing')} · ${record.weighed_qty ? record.weighed_qty + ' ' + tr('procurement.stageDesc.weighingDone') : tr('procurement.stageDesc.weighingProgress')}.`;
    case 'quality': return record.quality_grade || tr('procurement.stageDesc.quality');
    case 'recorded': return record.mandi_price ? `${tr('procurement.stageDesc.recordedPrefix')} ₹${record.mandi_price}/${tr('common.qtl')}` : tr('procurement.stageDesc.recordedFallback');
    case 'paid': return record.payment_ref ? `${tr('procurement.stageDesc.paidPrefix')} ${record.payment_ref}` : tr('procurement.stageDesc.paidFallback');
    default: return '';
  }
}

window.ProcurementPage = ProcurementPage;
