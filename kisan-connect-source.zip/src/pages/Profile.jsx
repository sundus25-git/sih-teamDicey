function ProfilePage() {
  const { go } = useRoute();
  const { farmer, signOut } = useApp();
  const toast = useToast();
  const { t } = useLang();
  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const [form, setForm] = React.useState({ ...farmer });
  const [saving, setSaving] = React.useState(false);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const save = async (ev) => {
    ev.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 400));
    window.db.from('farmers').update({
      name: form.name,
      mobile: form.mobile,
      crop: form.crop,
      quantity: parseFloat(form.quantity) || form.quantity,
      location: form.location,
      village: form.village,
      pincode: form.pincode,
      alt_contact: form.alt_contact
    }).eq('id', farmer.id);
    toast.push({ title: t('profile.toastUpdated') });
    setSaving(false);
  };

  const resetDemo = () => {
    if (!confirm(t('profile.resetConfirm'))) return;
    window.db.util.resetAll();
    toast.push({ title: t('profile.toastReset'), msg: t('profile.toastResetMsg') });
    setTimeout(() => { window.location.hash = '#/'; }, 400);
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-3xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <button onClick={() => go('/dashboard')} className="text-sm text-navy-500 hover:text-navy-800 flex items-center gap-1 mb-4"><Icons.ArrowLeft size={14}/> {t('profile.backDashboard')}</button>
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl bg-leaf-100 text-leaf-800 grid place-items-center font-display font-extrabold text-2xl">
            {farmer.name?.charAt(0).toUpperCase() || 'F'}
          </div>
          <div>
            <h1 className="font-display font-extrabold text-navy-900 text-2xl md:text-3xl tracking-tight">{farmer.name}</h1>
            <div className="text-sm text-navy-500">+91 {farmer.mobile} · {farmer.location}</div>
          </div>
        </div>

        <Card className="p-5 md:p-7">
          <div className="font-display font-bold text-navy-900 mb-4">{t('profile.farmerDetails')}</div>
          <form onSubmit={save} className="grid md:grid-cols-2 gap-4">
            <Field label={t('profile.name')} required><Input value={form.name || ''} onChange={set('name')}/></Field>
            <Field label={t('profile.mobile')} required><Input value={form.mobile || ''} onChange={set('mobile')}/></Field>
            <Field label={t('profile.primaryCrop')}>
              <Select value={form.crop || 'Wheat'} onChange={set('crop')}>
                {['Wheat', 'Paddy', 'Mustard', 'Sugarcane', 'Bajra', 'Cotton', 'Vegetables'].map((c) => <option key={c} value={c}>{t(`common.crops.${c}`)}</option>)}
              </Select>
            </Field>
            <Field label={t('profile.typicalQty')}><Input value={form.quantity || ''} onChange={set('quantity')}/></Field>
            <Field label={t('profile.district')}><Input value={form.location || ''} onChange={set('location')}/></Field>
            <Field label={t('profile.village')}><Input value={form.village || ''} onChange={set('village')}/></Field>
            <Field label={t('profile.pincode')}><Input value={form.pincode || ''} onChange={set('pincode')} maxLength={6}/></Field>
            <Field label={t('profile.altContact')}><Input value={form.alt_contact || ''} onChange={set('alt_contact')}/></Field>

            <div className="md:col-span-2 flex justify-end gap-2 mt-2">
              <Button variant="ghost" type="button" onClick={() => setForm({ ...farmer })}>{t('common.cancel')}</Button>
              <Button variant="leaf" type="submit" disabled={saving}>{saving ? t('profile.saving') : t('profile.saveChanges')}</Button>
            </div>
          </form>
        </Card>

        <Card className="p-5 mt-5">
          <div className="font-display font-bold text-navy-900 mb-1">{t('profile.demoControls')}</div>
          <div className="text-xs text-navy-500 mb-4">{t('profile.demoControlsSub')}</div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" onClick={() => { signOut(); go('/'); }}><Icons.LogOut size={14}/> {t('profile.signOut')}</Button>
            <Button variant="outline" size="sm" onClick={resetDemo}><Icons.Refresh size={14}/> {t('profile.resetAll')}</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

window.ProfilePage = ProfilePage;
