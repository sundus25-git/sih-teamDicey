function LandingPage() {
  const { go } = useRoute();
  const { farmer } = useApp();
  const { lang, setLang, t } = useLang();

  const features = [
    { icon: Icons.Sparkles, color: 'spice', key: 'predict' },
    { icon: Icons.Route,    color: 'navy',  key: 'allocate' },
    { icon: Icons.BarChart, color: 'leaf',  key: 'balance' },
    { icon: Icons.Clock,    color: 'amber', key: 'reduce' }
  ];

  const steps = [
    { n: 1, key: 'step1' },
    { n: 2, key: 'step2' },
    { n: 3, key: 'step3' },
    { n: 4, key: 'step4' }
  ];

  const stats = [
    { k: '5+', vKey: 'mandis' },
    { k: '38%', vKey: 'waitCut' },
    { k: '1,050', vKey: 'quintals' },
    { k: '4.7★', vKey: 'rating' }
  ];

  return (
    <div className="min-h-screen">
      {/* Top nav */}
      <header className="sticky top-0 z-30 bg-cream-50/85 backdrop-blur-md border-b border-cream-200">
        <div className="max-w-6xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-navy-800 grid place-items-center text-white">
              <Icons.Wheat size={20}/>
            </div>
            <div>
              <div className="font-display font-extrabold text-navy-900 text-[15px] leading-none">{t('brand.name')}</div>
              <div className="text-[10px] font-semibold uppercase tracking-wider text-navy-400 mt-0.5">{t('brand.tagline')}</div>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-1">
            <button onClick={() => document.getElementById('how')?.scrollIntoView({ behavior: 'smooth' })} className="px-4 py-2 rounded-xl hover:bg-cream-100 text-sm font-semibold text-navy-700">{t('nav.how')}</button>
            <button onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })} className="px-4 py-2 rounded-xl hover:bg-cream-100 text-sm font-semibold text-navy-700">{t('nav.features')}</button>
            <LanguageSwitch lang={lang} setLang={setLang}/>
            <Button size="sm" variant="outline" onClick={() => go('/queue')}>{t('nav.checkQueue')}</Button>
            <Button size="sm" onClick={() => go(farmer ? '/dashboard' : '/register')}>{farmer ? t('nav.dashboard') : t('nav.getStarted')}</Button>
          </nav>
          <div className="md:hidden flex items-center gap-2">
            <LanguageSwitch lang={lang} setLang={setLang} compact/>
            <Button size="sm" onClick={() => go(farmer ? '/dashboard' : '/register')}>{farmer ? t('nav.dashboard') : t('nav.start')}</Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10">
          <div className="absolute inset-0 bg-gradient-to-b from-cream-50 via-cream-50 to-white"/>
          <div className="absolute -top-32 -right-32 w-[600px] h-[600px] rounded-full bg-leaf-100 blur-3xl opacity-60"/>
          <div className="absolute -bottom-40 -left-20 w-[500px] h-[500px] rounded-full bg-spice-100 blur-3xl opacity-50"/>
        </div>

        <div className="max-w-6xl mx-auto px-4 md:px-8 pt-10 md:pt-20 pb-14 md:pb-24 grid md:grid-cols-2 gap-10 items-center">
          <div className="fade-up">
            <Badge color="leaf" className="mb-5">
              <Icons.Sparkles size={12}/> {t('hero.eyebrow')}
            </Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-4xl md:text-6xl leading-[1.05] tracking-tight">
              {t('hero.titleLine1')}{' '}
              <span className="relative inline-block">
                <span className="relative z-10">{t('hero.titleHighlight')}</span>
                <span className="absolute -bottom-1 left-0 right-0 h-3 bg-spice-200/70 -z-0 rounded"/>
              </span>{' '}
              {t('hero.titleLine2')}
            </h1>
            <p className="mt-5 text-lg text-navy-600 max-w-xl leading-relaxed">
              <span className="font-bold text-navy-900">{t('hero.subtitleBold')}</span>{' '}
              {t('hero.subtitle')}
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" variant="leaf" onClick={() => go(farmer ? '/planning' : '/register')}>
                {t('hero.ctaStart')} <Icons.ArrowRight size={18}/>
              </Button>
              <Button size="lg" variant="outline" onClick={() => go('/queue')}>
                <Icons.Clock size={18}/> {t('hero.ctaQueue')}
              </Button>
            </div>

            <div className="mt-8 flex items-center gap-6 text-xs text-navy-500 flex-wrap">
              <div className="flex items-center gap-2"><Icons.Shield size={14} className="text-leaf-600"/> {t('hero.trustAadhaar')}</div>
              <div className="flex items-center gap-2"><Icons.Phone size={14} className="text-navy-600"/> {t('hero.trustPhone')}</div>
              <div className="flex items-center gap-2"><Icons.Leaf size={14} className="text-leaf-600"/> {t('hero.trustCrop')}</div>
            </div>
          </div>

          {/* Right - hero visual card */}
          <div className="fade-up" style={{ animationDelay: '.1s' }}>
            <HeroCard t={t}/>
          </div>
        </div>
      </section>

      {/* Stat strip */}
      <section className="max-w-6xl mx-auto px-4 md:px-8 pb-14">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {stats.map((s, i) => (
            <div key={i} className="bg-white rounded-2xl border border-cream-200 p-4 md:p-5">
              <div className="font-display font-extrabold text-navy-900 text-2xl md:text-3xl">{s.k}</div>
              <div className="text-xs md:text-sm text-navy-500 mt-1">{t(`stats.${s.vKey}`)}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features - Predict / Allocate / Balance / Reduce Waiting */}
      <section id="features" className="max-w-6xl mx-auto px-4 md:px-8 py-16">
        <div className="max-w-2xl">
          <Badge color="navy" className="mb-4">{t('features.badge')}</Badge>
          <h2 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">
            {t('features.title')}
          </h2>
          <p className="mt-3 text-navy-600 leading-relaxed">
            {t('features.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-10">
          {features.map((f) => (
            <Card key={f.key} className="p-6">
              <div className={`w-11 h-11 rounded-2xl grid place-items-center mb-4
                ${f.color === 'spice' ? 'bg-spice-100 text-spice-600' :
                  f.color === 'leaf' ? 'bg-leaf-100 text-leaf-700' :
                  f.color === 'amber' ? 'bg-amber-100 text-amber-700' :
                  'bg-navy-100 text-navy-700'}`}>
                <f.icon size={22}/>
              </div>
              <div className="font-display font-bold text-navy-900 text-lg">{t(`features.${f.key}.title`)}</div>
              <div className="text-sm text-navy-500 mt-1 leading-relaxed">{t(`features.${f.key}.body`)}</div>
            </Card>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.04]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}/>
        <div className="max-w-6xl mx-auto px-4 md:px-8 relative">
          <div className="max-w-2xl mb-12">
            <Badge color="spice" className="mb-4">{t('how.badge')}</Badge>
            <h2 className="font-display font-extrabold text-3xl md:text-4xl tracking-tight">{t('how.title')}</h2>
          </div>

          <div className="grid md:grid-cols-4 gap-5">
            {steps.map((s, i) => (
              <div key={s.n} className="relative">
                <div className="text-6xl font-display font-extrabold text-spice-400/25 leading-none mb-3">{String(s.n).padStart(2, '0')}</div>
                <div className="font-display font-bold text-lg">{t(`how.${s.key}.title`)}</div>
                <div className="text-sm text-navy-200/70 mt-2 leading-relaxed">{t(`how.${s.key}.body`)}</div>
                {i < steps.length - 1 && <div className="hidden md:block absolute top-8 right-0 translate-x-1/2 text-navy-700"><Icons.ChevronRight size={20}/></div>}
              </div>
            ))}
          </div>

          <div className="mt-14 flex flex-wrap gap-3">
            <Button size="lg" variant="spice" onClick={() => go(farmer ? '/planning' : '/register')}>
              {farmer ? t('how.bookSlot') : t('how.registerFree')} <Icons.ArrowRight size={18}/>
            </Button>
            <Button size="lg" variant="outline" className="!bg-white/5 !text-white !border-white/20 hover:!bg-white/10" onClick={() => go('/queue')}>
              {t('how.liveQueue')}
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-4 md:px-8 py-12 grid md:grid-cols-3 gap-6 text-sm">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-8 h-8 rounded-lg bg-navy-800 grid place-items-center text-white"><Icons.Wheat size={16}/></div>
            <div className="font-display font-bold text-navy-900">{t('brand.name')}</div>
          </div>
          <div className="text-navy-500">{t('footer.tagline')}</div>
        </div>
        <div className="text-navy-500">
          {t('footer.builtFor')}
        </div>
        <div className="md:text-right text-navy-500">
          <div>{t('footer.helpline')}</div>
          <div className="mt-1 flex md:justify-end items-center gap-2">
            <span className="text-[11px] uppercase tracking-wider text-navy-400">{t('footer.language')}</span>
            <LanguageSwitch lang={lang} setLang={setLang}/>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* Illustrative hero card that hints at the whole product */
function HeroCard({ t }) {
  const load = [0,0,0,0,0,0,25,50,72,88,80,65,60,68,82,90,72,45,20,8,0,0,0,0];
  return (
    <Card className="p-5 md:p-6 relative">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('heroCard.recommended')}</div>
          <div className="font-display font-bold text-navy-900 text-xl mt-0.5">Karnal APMC Mandi</div>
          <div className="text-sm text-navy-500 flex items-center gap-1 mt-0.5"><Icons.MapPin size={13}/> Haryana · 14.2 km away</div>
        </div>
        <Badge color="leaf" dot>{t('heroCard.aiMatch')}</Badge>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2">
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('heroCard.wait')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-1">28 min</div>
        </div>
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('heroCard.slot')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-1">09:30</div>
        </div>
        <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3">
          <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('heroCard.load')}</div>
          <div className="font-display font-bold text-navy-900 text-lg mt-1">78%</div>
        </div>
      </div>

      <div className="mt-5">
        <div className="flex justify-between text-[11px] text-navy-500 mb-1">
          <span className="font-semibold">{t('heroCard.expectedLoad')}</span>
          <span>{t('heroCard.peak')}</span>
        </div>
        <LoadChart data={load} highlightHour={9}/>
      </div>

      <div className="mt-5 flex items-center justify-between p-3 rounded-2xl bg-navy-800 text-white">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-white/10 grid place-items-center"><Icons.QR size={18}/></div>
          <div>
            <div className="text-[11px] text-white/60 uppercase tracking-wider">{t('heroCard.digitalToken')}</div>
            <div className="font-display font-bold">KRN-0432</div>
          </div>
        </div>
        <Icons.ArrowRight size={18}/>
      </div>

      {/* floating alert */}
      <div className="absolute -bottom-4 -right-3 bg-white rounded-2xl border border-cream-200 shadow-pop px-3 py-2.5 flex items-center gap-2 max-w-[240px]">
        <div className="w-8 h-8 rounded-lg bg-leaf-100 text-leaf-700 grid place-items-center"><Icons.Check size={16}/></div>
        <div className="text-xs">
          <div className="font-semibold text-navy-900">{t('heroCard.queueFast')}</div>
          <div className="text-navy-500">{t('heroCard.farmersAhead')}</div>
        </div>
      </div>
    </Card>
  );
}

window.LandingPage = LandingPage;
