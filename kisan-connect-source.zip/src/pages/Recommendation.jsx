function RecommendationPage() {
  const { go, params } = useRoute();
  const { farmer, notify } = useApp();
  const toast = useToast();
  const { t } = useLang();

  React.useEffect(() => { if (!farmer) go('/register'); }, [farmer]);
  if (!farmer) return null;

  const date = params.date || new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const time = params.time || '09:00';
  const qty = parseFloat(params.qty || farmer.quantity || 30);
  const forcedMandi = params.mandi;

  const scored = React.useMemo(() => {
    return window.ai.recommend({ ...farmer, quantity: qty }, { date, time });
  }, [farmer, date, time, qty]);

  const [selectedId, setSelectedId] = React.useState(() => forcedMandi || scored[0]?.mandi.id);
  const selected = scored.find((s) => s.mandi.id === selectedId) || scored[0];

  const [compareIds, setCompareIds] = React.useState(() => scored.slice(0, 3).map((s) => s.mandi.id));

  const [confirming, setConfirming] = React.useState(false);

  const useRecommendedTime = selected && !forcedMandi;
  const finalHour = useRecommendedTime && selected.recommended_hour != null ? selected.recommended_hour : parseInt(time.split(':')[0], 10);
  const finalTime = `${String(finalHour).padStart(2, '0')}:${time.split(':')[1] || '00'}`;
  const finalWait = useRecommendedTime && selected.recommended_wait != null ? selected.recommended_wait : selected?.wait;

  const confirmBooking = async () => {
    if (!selected) return;
    setConfirming(true);
    await new Promise((r) => setTimeout(r, 700));

    const tokenNumber = selected.mandi.id.slice(-3).toUpperCase() + '-' + String(1000 + Math.floor(Math.random() * 8999));
    const { data: booking } = window.db.from('bookings').insert({
      farmer_id: farmer.id,
      mandi_id: selected.mandi.id,
      arrival_date: date,
      arrival_time: finalTime,
      quantity: qty,
      commodity: farmer.crop,
      status: 'confirmed',
      token: tokenNumber,
      score: selected.score,
      predicted_wait: finalWait,
      distance_km: selected.distance
    });

    // Add to queue (position = current waiting count + 1)
    const currentQueue = window.db.from('queue_entries').eq('mandi_id', selected.mandi.id).eq('status', 'waiting').select().data;
    window.db.from('queue_entries').insert({
      farmer_id: farmer.id,
      booking_id: booking.id,
      mandi_id: selected.mandi.id,
      position: currentQueue.length + 1,
      status: 'waiting',
      joined_at: new Date().toISOString()
    });

    // Initial procurement record
    window.db.from('procurement_records').insert({
      farmer_id: farmer.id,
      booking_id: booking.id,
      mandi_id: selected.mandi.id,
      commodity: farmer.crop,
      quantity: qty,
      stage: 'checkin_pending',
      payment_status: 'pending'
    });

    // Notifications
    notify({
      type: 'booking',
      title: 'Booking confirmed',
      body: `Slot at ${selected.mandi.name} on ${prettyDate(date)} at ${finalTime}. Your token: ${tokenNumber}.`
    });
    notify({
      type: 'reminder',
      title: 'Arrival reminder scheduled',
      body: `We'll remind you 1 hour before your slot at ${finalTime} on ${prettyDate(date)}.`
    });

    toast.push({ title: t('recommendation.toastConfirmed'), msg: t('recommendation.toastTokenMsg', { token: tokenNumber }) });
    setConfirming(false);
    go('/confirm?booking=' + booking.id);
  };

  return (
    <div className="min-h-screen pb-24 md:pb-8">
      <AppHeader/>
      <div className="max-w-6xl mx-auto px-4 md:px-8 py-6 md:py-10">
        <button onClick={() => go('/planning')} className="text-sm text-navy-500 hover:text-navy-800 flex items-center gap-1 mb-4"><Icons.ArrowLeft size={14}/> {t('recommendation.changeDetails')}</button>

        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <Badge color="spice" className="mb-3"><Icons.Sparkles size={12}/> {t('recommendation.badge')}</Badge>
            <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('recommendation.title')}</h1>
            <p className="text-navy-500 mt-2 max-w-xl">{t('recommendation.subtitle')} {prettyDate(date)}.</p>
          </div>
          <Stepper current={2} steps={[
            { label: t('recommendation.steps.register') }, { label: t('recommendation.steps.plan') }, { label: t('recommendation.steps.recommend') }, { label: t('recommendation.steps.confirm') }, { label: t('recommendation.steps.track') }
          ]}/>
        </div>

        {/* Featured recommendation */}
        {selected && (
          <div className="mt-8 grid lg:grid-cols-[1.4fr_1fr] gap-4">
            <Card className="p-6 relative overflow-hidden">
              <div className="absolute -right-16 -top-16 w-64 h-64 rounded-full bg-leaf-100/60 blur-3xl"/>
              <div className="relative">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <div className="text-xs font-semibold text-leaf-700 uppercase tracking-wider">{t('recommendation.recommendedCentre')}</div>
                    <div className="font-display font-extrabold text-navy-900 text-2xl md:text-3xl mt-1">{selected.mandi.name}</div>
                    <div className="text-sm text-navy-500 flex items-center gap-1 mt-1"><Icons.MapPin size={13}/> {selected.mandi.district}, {selected.mandi.state}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-semibold text-navy-400 uppercase tracking-wider">{t('recommendation.aiScore')}</div>
                    <div className="font-display font-extrabold text-4xl text-leaf-600">{selected.score}</div>
                    <div className="text-[10px] text-navy-400">/ 100</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6">
                  <StatTile icon={Icons.Clock} label={t('recommendation.recommendedArrival')} value={finalTime} sub={prettyDate(date)}/>
                  <StatTile icon={Icons.Users} label={t('recommendation.expectedWait')} value={finalWait + ' ' + t('common.min')} sub={useRecommendedTime ? t('recommendation.aiOptimised') : t('recommendation.yourChosenSlot')}/>
                  <StatTile icon={Icons.Route} label={t('recommendation.distance')} value={selected.distance + ' ' + t('common.km')} sub={t('recommendation.fromPincode')}/>
                  <StatTile icon={Icons.BarChart} label={t('recommendation.centreLoad')} value={selected.congestion + '%'} sub={selected.congestion < 60 ? t('planning.smooth') : selected.congestion < 85 ? t('planning.moderate') : t('planning.heavy')}/>
                </div>

                <div className="mt-6 rounded-2xl bg-navy-800 text-white p-4">
                  <div className="flex items-start gap-3">
                    <Icons.Sparkles size={18} className="text-spice-300 flex-none mt-0.5"/>
                    <div>
                      <div className="font-semibold text-sm">{t('recommendation.whyTitle')}</div>
                      <div className="text-sm text-white/75 mt-1 leading-relaxed">
                        {reasonText(selected, farmer, useRecommendedTime, finalHour, parseInt(time.split(':')[0], 10), t)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  <Button variant="leaf" size="lg" onClick={confirmBooking} disabled={confirming}>
                    {confirming ? t('recommendation.booking') : <>{t('recommendation.confirmCentre')} <Icons.Check size={16}/></>}
                  </Button>
                  <Button variant="outline" size="lg" onClick={() => go('/planning')}>{t('recommendation.compareMore')}</Button>
                </div>
              </div>
            </Card>

            {/* Right - load chart */}
            <Card className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-navy-400 uppercase tracking-wider">{t('recommendation.predictedLoad')}</div>
                  <div className="font-display font-bold text-navy-900 mt-1">{t('recommendation.hourlyCongestion')} {selected.mandi.name}</div>
                </div>
                <Icons.BarChart className="text-navy-400"/>
              </div>
              <div className="mt-6">
                <LoadChart data={window.ai.predictCentreLoad(selected.mandi.id, date)} highlightHour={finalHour} height={140}/>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                <LegendDot color="bg-cream-300" label={t('recommendation.quiet')}/>
                <LegendDot color="bg-leaf-400" label={t('recommendation.normal')}/>
                <LegendDot color="bg-spice-400" label={t('recommendation.busy')}/>
              </div>
              <div className="mt-4 rounded-2xl bg-cream-50 p-3 text-xs text-navy-600">
                <span className="font-semibold text-navy-800">{t('recommendation.peakHours')}</span>{' '}
                {window.ai.detectPeakHours(selected.mandi).map(h => `${h}:00`).join(', ')}. {t('recommendation.peakNote')}
              </div>
            </Card>
          </div>
        )}

        {/* Compare */}
        <div className="mt-10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <div className="text-sm font-semibold text-navy-800">{t('recommendation.compareTitle')}</div>
              <div className="text-xs text-navy-500">{t('recommendation.compareSub')}</div>
            </div>
          </div>
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-cream-50 text-navy-500 text-xs uppercase tracking-wider">
                    <th className="text-left py-3 px-4 font-semibold">{t('recommendation.table.centre')}</th>
                    <th className="text-left py-3 px-4 font-semibold">{t('recommendation.table.distance')}</th>
                    <th className="text-left py-3 px-4 font-semibold">{t('recommendation.table.wait')}</th>
                    <th className="text-left py-3 px-4 font-semibold">{t('recommendation.table.load')}</th>
                    <th className="text-left py-3 px-4 font-semibold">{t('recommendation.table.score')}</th>
                    <th className="text-right py-3 px-4 font-semibold">{t('recommendation.table.action')}</th>
                  </tr>
                </thead>
                <tbody>
                  {scored.map((s, i) => (
                    <tr key={s.mandi.id} className={`border-t border-cream-200 hover:bg-cream-50 cursor-pointer ${selectedId === s.mandi.id ? 'bg-leaf-50/40' : ''}`} onClick={() => setSelectedId(s.mandi.id)}>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-navy-900">{s.mandi.name}</div>
                        <div className="text-xs text-navy-500">{s.mandi.district}</div>
                      </td>
                      <td className="py-3 px-4 text-navy-700">{s.distance} {t('common.km')}</td>
                      <td className="py-3 px-4 text-navy-700">{s.wait} {t('common.min')}</td>
                      <td className="py-3 px-4"><div className="w-24"><CapacityBar value={s.congestion} size="sm"/></div></td>
                      <td className="py-3 px-4">
                        <span className={`font-display font-extrabold ${s.score >= 75 ? 'text-leaf-600' : s.score >= 55 ? 'text-spice-600' : 'text-navy-500'}`}>{s.score}</span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <Button size="sm" variant={selectedId === s.mandi.id ? 'leaf' : 'outline'} onClick={(e) => { e.stopPropagation(); setSelectedId(s.mandi.id); }}>
                          {selectedId === s.mandi.id ? t('recommendation.table.selected') : t('recommendation.table.select')}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatTile({ icon: I, label, value, sub }) {
  return (
    <div className="rounded-2xl bg-cream-50 border border-cream-200 p-3.5">
      <div className="flex items-center gap-2 text-navy-500">
        <I size={14}/>
        <span className="text-[10px] font-semibold uppercase tracking-wider">{label}</span>
      </div>
      <div className="font-display font-bold text-navy-900 text-xl mt-1">{value}</div>
      {sub && <div className="text-[11px] text-navy-500 mt-0.5">{sub}</div>}
    </div>
  );
}

function LegendDot({ color, label }) {
  return <div className="flex items-center gap-1.5 text-navy-500"><span className={`w-3 h-3 rounded ${color}`}/>{label}</div>;
}

function prettyDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

function reasonText(s, farmer, timeShifted, recHour, origHour, t) {
  const tr = t || window.i18n.t;
  const bits = [];
  if (s.score >= 75) bits.push(tr('recommendation.reasons.excellentScore', { score: s.score }));
  if (s.distance < 15) bits.push(tr('recommendation.reasons.veryClose', { km: s.distance, location: farmer.location || tr('recommendation.reasons.district') }));
  else if (s.distance < 30) bits.push(tr('recommendation.reasons.withinRange', { km: s.distance }));
  if (s.wait < 30) bits.push(tr('recommendation.reasons.fastWait', { min: s.wait }));
  else if (s.wait < 50) bits.push(tr('recommendation.reasons.moderateWait', { min: s.wait }));
  if (s.mandi.commodities.includes(farmer.crop)) bits.push(tr('recommendation.reasons.handlesCrop', { crop: tr(`common.crops.${farmer.crop}`) }));
  if (timeShifted && recHour !== origHour) bits.push(tr('recommendation.reasons.shiftedTime', { orig: origHour, rec: recHour }));
  if (s.congestion < 60) bits.push(tr('recommendation.reasons.lowLoad'));
  return bits.slice(0, 4).join(' ');
}

window.RecommendationPage = RecommendationPage;
