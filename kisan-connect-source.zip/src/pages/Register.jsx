function RegisterPage() {
  const { go } = useRoute();
  const { farmerId, signIn, notify } = useApp();
  const toast = useToast();
  const { t } = useLang();

  const [form, setForm] = React.useState({
    name: '', mobile: '', crop: 'Wheat', quantity: '', location: '', pincode: '',
    village: '', altContact: ''
  });
  const [errors, setErrors] = React.useState({});
  const [submitting, setSubmitting] = React.useState(false);

  const crops = ['Wheat', 'Paddy', 'Mustard', 'Sugarcane', 'Bajra', 'Cotton', 'Vegetables'];

  // If already registered, redirect
  React.useEffect(() => { if (farmerId) go('/dashboard'); }, [farmerId]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const validate = () => {
    const e = {};
    if (!form.name.trim() || form.name.trim().length < 2) e.name = t('register.errors.name');
    if (!/^[6-9]\d{9}$/.test(form.mobile.replace(/\s/g, ''))) e.mobile = t('register.errors.mobile');
    if (!form.crop) e.crop = t('register.errors.crop');
    const q = parseFloat(form.quantity);
    if (!q || q <= 0) e.quantity = t('register.errors.quantity');
    if (q > 500) e.quantity = t('register.errors.quantityHigh');
    if (!form.location.trim()) e.location = t('register.errors.location');
    if (form.pincode && !/^\d{6}$/.test(form.pincode)) e.pincode = t('register.errors.pincode');
    if (form.altContact && !/^[6-9]\d{9}$/.test(form.altContact.replace(/\s/g, ''))) e.altContact = t('register.errors.altContact');
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = async (ev) => {
    ev.preventDefault();
    if (!validate()) {
      toast.push({ title: t('register.toastFix'), tone: 'error' });
      return;
    }
    setSubmitting(true);
    // Simulate small delay so the user sees loading state
    await new Promise((r) => setTimeout(r, 600));
    const { data } = window.db.from('farmers').insert({
      name: form.name.trim(),
      mobile: form.mobile.trim(),
      crop: form.crop,
      quantity: parseFloat(form.quantity),
      location: form.location.trim(),
      village: form.village.trim(),
      pincode: form.pincode.trim(),
      alt_contact: form.altContact.trim(),
      // Rough approx: place farmer near Haryana centroid + jitter based on pincode
      lat: 29.4 + (parseInt(form.pincode || '132001', 10) % 50) * 0.01,
      lng: 76.7 + (parseInt(form.pincode || '132001', 10) % 60) * 0.01
    });
    signIn(data.id);
    // Welcome notification
    window.db.from('notifications').insert({
      farmer_id: data.id,
      type: 'welcome',
      title: 'Welcome to Kisan Connect',
      body: `Namaste ${data.name.split(' ')[0]}! Your farmer profile is ready. Let's book your first procurement slot.`,
      read: false,
      ts: new Date().toISOString()
    });
    toast.push({ title: t('register.toastDone'), msg: t('register.toastDoneMsg') });
    setSubmitting(false);
    go('/planning');
  };

  return (
    <div className="min-h-screen">
      <AppHeader/>
      <div className="max-w-3xl mx-auto px-4 md:px-8 py-8 md:py-12">
        <button onClick={() => go('/')} className="text-sm text-navy-500 hover:text-navy-800 flex items-center gap-1 mb-4"><Icons.ArrowLeft size={14}/> {t('common.back')}</button>
        <Badge color="leaf" className="mb-3">{t('register.step')}</Badge>
        <h1 className="font-display font-extrabold text-navy-900 text-3xl md:text-4xl tracking-tight">{t('register.title')}</h1>
        <p className="text-navy-500 mt-2 max-w-lg">{t('register.subtitle')}</p>

        <form onSubmit={submit} className="mt-8" noValidate>
          <Card className="p-5 md:p-7">
            <div className="grid md:grid-cols-2 gap-5">
              <Field label={t('register.name')} required error={errors.name}>
                <Input value={form.name} onChange={set('name')} placeholder={t('register.namePh')} invalid={!!errors.name}/>
              </Field>

              <Field label={t('register.mobile')} required hint={t('register.mobileHint')} error={errors.mobile}>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-navy-500 text-sm font-medium">+91</span>
                  <Input value={form.mobile} onChange={set('mobile')} placeholder="98XXXXXXXX" className="!pl-12" invalid={!!errors.mobile} inputMode="numeric" maxLength={10}/>
                </div>
              </Field>

              <Field label={t('register.crop')} required error={errors.crop}>
                <Select value={form.crop} onChange={set('crop')} invalid={!!errors.crop}>
                  {crops.map((c) => <option key={c} value={c}>{t(`common.crops.${c}`)}</option>)}
                </Select>
              </Field>

              <Field label={t('register.quantity')} required hint={t('register.quantityHint')} error={errors.quantity}>
                <div className="relative">
                  <Input value={form.quantity} onChange={set('quantity')} placeholder={t('register.quantityPh')} invalid={!!errors.quantity} inputMode="decimal"/>
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-navy-400 text-sm font-medium">{t('common.qtl')}</span>
                </div>
              </Field>

              <Field label={t('register.district')} required error={errors.location}>
                <Input value={form.location} onChange={set('location')} placeholder={t('register.districtPh')} invalid={!!errors.location}/>
              </Field>

              <Field label={t('register.village')} hint={t('common.optional')}>
                <Input value={form.village} onChange={set('village')} placeholder={t('register.villagePh')}/>
              </Field>

              <Field label={t('register.pincode')} hint={t('register.pincodeHint')} error={errors.pincode}>
                <Input value={form.pincode} onChange={set('pincode')} placeholder="132001" invalid={!!errors.pincode} inputMode="numeric" maxLength={6}/>
              </Field>

              <Field label={t('register.altContact')} hint={t('common.optional')} error={errors.altContact}>
                <Input value={form.altContact} onChange={set('altContact')} placeholder={t('register.altContactPh')} invalid={!!errors.altContact} inputMode="numeric" maxLength={10}/>
              </Field>
            </div>

            <div className="mt-6 bg-cream-50 rounded-2xl p-4 flex gap-3">
              <div className="w-9 h-9 rounded-xl bg-leaf-100 text-leaf-700 grid place-items-center flex-none"><Icons.Shield size={18}/></div>
              <div className="text-xs text-navy-600">
                <span className="font-semibold text-navy-800">{t('register.privacyTitle')}</span> {t('register.privacyBody')}
              </div>
            </div>

            <div className="mt-6 flex flex-col-reverse md:flex-row md:justify-end gap-3">
              <Button variant="ghost" as="a" href="#/" type="button">{t('common.cancel')}</Button>
              <Button type="submit" variant="leaf" disabled={submitting}>
                {submitting ? t('register.submitting') : <>{t('register.continue')} <Icons.ArrowRight size={16}/></>}
              </Button>
            </div>
          </Card>
        </form>
      </div>
    </div>
  );
}

/* Shared app header for authenticated pages */
function AppHeader({ compact = false }) {
  const { farmer, signOut } = useApp();
  const { go, path } = useRoute();
  const { lang, setLang, t } = useLang();
  const [menuOpen, setMenuOpen] = React.useState(false);

  const unread = useTable('notifications', (n) => n.farmer_id === farmer?.id && !n.read).length;

  const links = [
    { p: '/dashboard', label: t('header.nav.home'), icon: Icons.Home },
    { p: '/planning', label: t('header.nav.book'), icon: Icons.Calendar },
    { p: '/queue', label: t('header.nav.queue'), icon: Icons.Users },
    { p: '/procurement', label: t('header.nav.status'), icon: Icons.Package },
    { p: '/notifications', label: t('header.nav.alerts'), icon: Icons.Bell, badge: unread }
  ];

  return (
    <>
      <header className="sticky top-0 z-30 bg-cream-50/85 backdrop-blur-md border-b border-cream-200">
        <div className="max-w-6xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          <button onClick={() => go(farmer ? '/dashboard' : '/')} className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-navy-800 grid place-items-center text-white">
              <Icons.Wheat size={20}/>
            </div>
            <div className="text-left">
              <div className="font-display font-extrabold text-navy-900 text-[15px] leading-none">{t('brand.name')}</div>
              <div className="text-[10px] font-semibold uppercase tracking-wider text-navy-400 mt-0.5">{t('brand.tagline')}</div>
            </div>
          </button>

          {farmer && (
            <nav className="hidden md:flex items-center gap-1">
              {links.map((l) => {
                const active = path.startsWith(l.p);
                return (
                  <button key={l.p} onClick={() => go(l.p)}
                    className={`relative px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition
                      ${active ? 'bg-navy-800 text-white' : 'text-navy-700 hover:bg-cream-100'}`}>
                    <l.icon size={16}/> {l.label}
                    {l.badge > 0 && <span className="ml-0.5 w-4 h-4 rounded-full bg-spice-500 text-white text-[9px] font-bold grid place-items-center">{l.badge}</span>}
                  </button>
                );
              })}
            </nav>
          )}

          <div className="flex items-center gap-2">
            <LanguageSwitch lang={lang} setLang={setLang} compact/>
            {farmer && (
              <button onClick={() => go('/notifications')} className="md:hidden relative w-10 h-10 rounded-xl hover:bg-cream-100 grid place-items-center text-navy-700">
                <Icons.Bell size={18}/>
                {unread > 0 && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-spice-500"/>}
              </button>
            )}
            {farmer ? (
              <button onClick={() => setMenuOpen((v) => !v)} className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-full hover:bg-cream-100 relative">
                <div className="w-8 h-8 rounded-full bg-leaf-100 text-leaf-800 grid place-items-center font-display font-bold text-sm">
                  {farmer.name?.charAt(0).toUpperCase() || 'F'}
                </div>
                <span className="hidden md:block text-sm font-semibold text-navy-800">{farmer.name?.split(' ')[0]}</span>
                {menuOpen && (
                  <div className="absolute top-full right-0 mt-2 bg-white rounded-2xl border border-cream-200 shadow-pop py-2 min-w-[180px] text-left" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => { setMenuOpen(false); go('/profile'); }} className="w-full text-left px-4 py-2 hover:bg-cream-50 text-sm flex items-center gap-2 text-navy-800"><Icons.User size={15}/> {t('header.menu.profile')}</button>
                    <button onClick={() => { setMenuOpen(false); go('/dashboard'); }} className="w-full text-left px-4 py-2 hover:bg-cream-50 text-sm flex items-center gap-2 text-navy-800"><Icons.Home size={15}/> {t('header.menu.dashboard')}</button>
                    <div className="border-t border-cream-200 my-1"/>
                    <button onClick={() => { setMenuOpen(false); signOut(); go('/'); }} className="w-full text-left px-4 py-2 hover:bg-cream-50 text-sm flex items-center gap-2 text-red-600"><Icons.LogOut size={15}/> {t('header.menu.signOut')}</button>
                  </div>
                )}
              </button>
            ) : (
              <Button size="sm" onClick={() => go('/register')}>{t('header.getStarted')}</Button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile bottom nav */}
      {farmer && (
        <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur border-t border-cream-200 md:hidden safe-bottom pt-2">
          <div className="grid grid-cols-5 max-w-md mx-auto">
            {links.map((l) => {
              const active = path.startsWith(l.p);
              return (
                <button key={l.p} onClick={() => go(l.p)} className="relative flex flex-col items-center py-1.5 gap-0.5">
                  <l.icon size={20} className={active ? 'text-navy-800' : 'text-navy-400'}/>
                  <span className={`text-[10px] font-semibold ${active ? 'text-navy-800' : 'text-navy-400'}`}>{l.label}</span>
                  {l.badge > 0 && <span className="absolute top-0 right-1/4 w-4 h-4 rounded-full bg-spice-500 text-white text-[9px] font-bold grid place-items-center">{l.badge}</span>}
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </>
  );
}

window.RegisterPage = RegisterPage;
window.AppHeader = AppHeader;
