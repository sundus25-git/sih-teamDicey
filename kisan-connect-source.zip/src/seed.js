/*
 * Seeds mandis, centre_capacity, historical_arrivals on first load.
 * Idempotent: only seeds if the mandis table is empty.
 */
(function () {
  const SEED_VERSION = 3;
  const seededVersion = parseInt(localStorage.getItem('td.seed_version') || '0', 10);

  if (seededVersion >= SEED_VERSION) return;

  // Clear stale seed tables (keep farmers/bookings so we don't wipe user work if version bumps)
  ['mandis', 'centre_capacity', 'historical_arrivals'].forEach((t) => localStorage.removeItem('td.' + t));

  const mandis = [
    {
      id: 'mandi_karnal',
      name: 'Karnal APMC Mandi',
      state: 'Haryana',
      district: 'Karnal',
      lat: 29.6857, lng: 76.9905,
      commodities: ['Wheat', 'Paddy', 'Mustard', 'Sugarcane'],
      hours: '06:00 – 18:00',
      operator: 'HSAMB',
      contact: '+91 184 220 1122',
      capacity_per_day: 1200,   // quintals
      lanes: 6,
      avg_processing_min: 22,   // per farmer entry
      base_load_pct: 82
    },
    {
      id: 'mandi_kaithal',
      name: 'Kaithal Grain Market',
      state: 'Haryana',
      district: 'Kaithal',
      lat: 29.8010, lng: 76.3985,
      commodities: ['Wheat', 'Paddy', 'Bajra'],
      hours: '06:00 – 19:00',
      operator: 'HSAMB',
      contact: '+91 1746 220 900',
      capacity_per_day: 900,
      lanes: 4,
      avg_processing_min: 26,
      base_load_pct: 64
    },
    {
      id: 'mandi_panipat',
      name: 'Panipat Anaj Mandi',
      state: 'Haryana',
      district: 'Panipat',
      lat: 29.3909, lng: 76.9635,
      commodities: ['Wheat', 'Mustard', 'Cotton'],
      hours: '05:30 – 18:30',
      operator: 'HSAMB',
      contact: '+91 180 264 5501',
      capacity_per_day: 1050,
      lanes: 5,
      avg_processing_min: 24,
      base_load_pct: 71
    },
    {
      id: 'mandi_sonipat',
      name: 'Sonipat Regulated Mandi',
      state: 'Haryana',
      district: 'Sonipat',
      lat: 28.9931, lng: 77.0151,
      commodities: ['Wheat', 'Paddy', 'Vegetables'],
      hours: '06:00 – 18:00',
      operator: 'HSAMB',
      contact: '+91 130 224 8811',
      capacity_per_day: 800,
      lanes: 4,
      avg_processing_min: 20,
      base_load_pct: 55
    },
    {
      id: 'mandi_jind',
      name: 'Jind Krishi Upaj Mandi',
      state: 'Haryana',
      district: 'Jind',
      lat: 29.3140, lng: 76.3155,
      commodities: ['Wheat', 'Paddy', 'Bajra', 'Cotton'],
      hours: '06:30 – 18:00',
      operator: 'HSAMB',
      contact: '+91 1681 245 300',
      capacity_per_day: 700,
      lanes: 3,
      avg_processing_min: 28,
      base_load_pct: 48
    }
  ];

  // hourly capacity utilisation curve (24 slots, 06 - 18 active)
  const curve = [0,0,0,0,0,0, 30,55,80,92,88,75, 68,72,85,90,72,50, 22,10,0,0,0,0];

  const centre_capacity = mandis.map((m) => ({
    id: 'cap_' + m.id,
    mandi_id: m.id,
    hourly_utilisation_pct: curve.map((v) => Math.max(0, Math.min(100, v + (m.base_load_pct - 65) * 0.4))),
    updated_at: new Date().toISOString()
  }));

  // historical arrivals: last 14 days aggregate per mandi
  const historical = [];
  for (const m of mandis) {
    for (let d = 13; d >= 0; d--) {
      const day = new Date(Date.now() - d * 86400000);
      const dow = day.getDay(); // 0 sun, 6 sat
      const weekend = dow === 0 || dow === 6;
      const base = m.capacity_per_day * (weekend ? 0.55 : 0.9);
      const noise = (Math.sin((d + m.id.length) * 1.3) * 0.15 + 1);
      historical.push({
        id: 'hist_' + m.id + '_' + d,
        mandi_id: m.id,
        date: day.toISOString().slice(0, 10),
        farmers_count: Math.round(base * noise / 8),
        quintals_procured: Math.round(base * noise),
        peak_hour: weekend ? 11 : 10,
        avg_wait_min: Math.round(35 + (m.base_load_pct - 60) * 0.7 + (weekend ? -8 : 0))
      });
    }
  }

  localStorage.setItem('td.mandis', JSON.stringify(mandis));
  localStorage.setItem('td.centre_capacity', JSON.stringify(centre_capacity));
  localStorage.setItem('td.historical_arrivals', JSON.stringify(historical));
  localStorage.setItem('td.seed_version', String(SEED_VERSION));
})();
