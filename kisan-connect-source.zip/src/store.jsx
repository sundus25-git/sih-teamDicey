/*
 * App-wide store: current farmer session + helper hooks that read/write via db.
 */
const AppCtx = React.createContext(null);

function AppProvider({ children }) {
  const [farmerId, setFarmerId] = React.useState(() => window.db.auth.getCurrent());
  const [tableVersion, setTableVersion] = React.useState(0);

  React.useEffect(() => {
    const onSession = () => setFarmerId(window.db.auth.getCurrent());
    const onTable = () => setTableVersion((v) => v + 1);
    window.addEventListener('td:session', onSession);
    window.addEventListener('td:table', onTable);
    window.addEventListener('td:reset', onSession);
    return () => {
      window.removeEventListener('td:session', onSession);
      window.removeEventListener('td:table', onTable);
      window.removeEventListener('td:reset', onSession);
    };
  }, []);

  const farmer = React.useMemo(() => {
    if (!farmerId) return null;
    const { data } = window.db.from('farmers').eq('id', farmerId).single();
    return data;
  }, [farmerId, tableVersion]);

  const signIn = (id) => window.db.auth.setCurrent(id);
  const signOut = () => window.db.auth.signOut();

  const notify = (payload) => {
    if (!farmerId) return;
    return window.db.from('notifications').insert({
      farmer_id: farmerId,
      read: false,
      ts: new Date().toISOString(),
      ...payload
    });
  };

  return (
    <AppCtx.Provider value={{ farmer, farmerId, signIn, signOut, notify, tableVersion }}>
      {children}
    </AppCtx.Provider>
  );
}

const useApp = () => React.useContext(AppCtx);

/* Convenience hook that returns rows + auto-refreshes on writes */
function useTable(name, filterFn) {
  const { tableVersion } = useApp() || { tableVersion: 0 };
  return React.useMemo(() => {
    let rows = window.db.from(name).select().data;
    if (filterFn) rows = rows.filter(filterFn);
    return rows;
    // eslint-disable-next-line
  }, [name, tableVersion]);
}

Object.assign(window, { AppProvider, useApp, useTable });
