/*
 * Inline SVG icons (lucide-style, 24x24, 1.75 stroke).
 * Exposed as window.Icons.<name>. All accept `size` and `className` props.
 */
const iconBase = {
  xmlns: 'http://www.w3.org/2000/svg',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.75,
  strokeLinecap: 'round',
  strokeLinejoin: 'round'
};
const Icon = ({ size = 20, className = '', children, viewBox = '0 0 24 24' }) => (
  <svg {...iconBase} width={size} height={size} viewBox={viewBox} className={className} aria-hidden="true">{children}</svg>
);

const Icons = {
  Wheat: (p) => <Icon {...p}><path d="M12 21V7"/><path d="M12 7c-2-2-4-2-6-2 0 2 0 4 2 6l4-4z"/><path d="M12 7c2-2 4-2 6-2 0 2 0 4-2 6l-4-4z"/><path d="M12 12c-2-2-4-2-6-2 0 2 0 4 2 6l4-4z"/><path d="M12 12c2-2 4-2 6-2 0 2 0 4-2 6l-4-4z"/><path d="M12 17c-2-2-4-2-6-2 0 2 0 4 2 6l4-4z"/><path d="M12 17c2-2 4-2 6-2 0 2 0 4-2 6l-4-4z"/></Icon>,
  Leaf: (p) => <Icon {...p}><path d="M11 20A7 7 0 0 1 4 13c0-6 5-9 16-9 0 11-3 16-9 16Z"/><path d="M2 22c0-6 5-11 11-13"/></Icon>,
  Truck: (p) => <Icon {...p}><path d="M14 18V6H3v12h3"/><path d="M14 8h4l3 4v6h-3"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></Icon>,
  MapPin: (p) => <Icon {...p}><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></Icon>,
  Clock: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></Icon>,
  Calendar: (p) => <Icon {...p}><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></Icon>,
  Users: (p) => <Icon {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></Icon>,
  Phone: (p) => <Icon {...p}><path d="M22 16.9v3a2 2 0 0 1-2.2 2 20 20 0 0 1-8.6-3.1 20 20 0 0 1-6-6A20 20 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8 9.7a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2Z"/></Icon>,
  Sparkles: (p) => <Icon {...p}><path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3z"/><path d="M19 15l.7 2 2 .7-2 .7L19 20l-.7-2-2-.7 2-.7L19 15z"/><path d="M5 15l.6 1.7L7 17l-1.4.4L5 19l-.6-1.7L3 17l1.4-.4L5 15z"/></Icon>,
  Check: (p) => <Icon {...p}><path d="M5 12l5 5 9-11"/></Icon>,
  ChevronRight: (p) => <Icon {...p}><path d="M9 6l6 6-6 6"/></Icon>,
  ChevronLeft: (p) => <Icon {...p}><path d="M15 6l-6 6 6 6"/></Icon>,
  ArrowRight: (p) => <Icon {...p}><path d="M5 12h14M13 5l7 7-7 7"/></Icon>,
  ArrowLeft: (p) => <Icon {...p}><path d="M19 12H5M11 5l-7 7 7 7"/></Icon>,
  Bell: (p) => <Icon {...p}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M14 21a2 2 0 0 1-4 0"/></Icon>,
  Home: (p) => <Icon {...p}><path d="M3 10l9-7 9 7"/><path d="M5 9v11h5v-6h4v6h5V9"/></Icon>,
  QR: (p) => <Icon {...p}><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3M20 14v3M14 20h3M20 17v4"/></Icon>,
  Package: (p) => <Icon {...p}><path d="M16.5 9.4 7.5 4.2"/><path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"/><path d="M3.3 7 12 12l8.7-5"/><path d="M12 22V12"/></Icon>,
  Weight: (p) => <Icon {...p}><circle cx="12" cy="5" r="3"/><path d="M6.5 8h11l2 11a2 2 0 0 1-2 2h-11a2 2 0 0 1-2-2l2-11z"/></Icon>,
  IndianRupee: (p) => <Icon {...p}><path d="M6 3h12M6 8h12M8 21l7-13H6"/></Icon>,
  Alert: (p) => <Icon {...p}><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></Icon>,
  Cloud: (p) => <Icon {...p}><path d="M17.5 19a4.5 4.5 0 1 0-1.9-8.6 6 6 0 1 0-11.5 3.1A4 4 0 0 0 5 19h12.5Z"/></Icon>,
  Route: (p) => <Icon {...p}><circle cx="6" cy="19" r="3"/><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"/><circle cx="18" cy="5" r="3"/></Icon>,
  Zap: (p) => <Icon {...p}><path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/></Icon>,
  Shield: (p) => <Icon {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/></Icon>,
  BarChart: (p) => <Icon {...p}><path d="M3 3v18h18"/><rect x="7" y="12" width="3" height="6"/><rect x="12" y="7" width="3" height="11"/><rect x="17" y="10" width="3" height="8"/></Icon>,
  Menu: (p) => <Icon {...p}><path d="M4 6h16M4 12h16M4 18h16"/></Icon>,
  X: (p) => <Icon {...p}><path d="M18 6 6 18M6 6l12 12"/></Icon>,
  User: (p) => <Icon {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></Icon>,
  LogOut: (p) => <Icon {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></Icon>,
  Refresh: (p) => <Icon {...p}><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></Icon>,
  Filter: (p) => <Icon {...p}><path d="M22 3H2l8 9v7l4 2v-9l8-9z"/></Icon>,
  Info: (p) => <Icon {...p}><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v5h1"/></Icon>,
  Star: (p) => <Icon {...p}><path d="m12 2 3 7 7 .5-5.4 4.6L18.2 22 12 18.3 5.8 22l1.6-7.9L2 9.5 9 9l3-7z"/></Icon>,
  Send: (p) => <Icon {...p}><path d="M22 2 11 13M22 2l-7 20-4-9-9-4 20-7z"/></Icon>,
  Wallet: (p) => <Icon {...p}><path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h16v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7"/><circle cx="17" cy="14" r="1"/></Icon>,
  Location: (p) => <Icon {...p}><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/></Icon>,
  Search: (p) => <Icon {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-4.35-4.35"/></Icon>,
  Circle: (p) => <Icon {...p}><circle cx="12" cy="12" r="4"/></Icon>,
  Dot: (p) => <Icon {...p}><circle cx="12" cy="12" r="2" fill="currentColor"/></Icon>
};

window.Icons = Icons;
