/*
 * Recommendation & prediction engine.
 * Deterministic, isolated so it can later be swapped for a real ML/AI endpoint.
 *
 * Public API (window.ai):
 *   ai.predictCentreLoad(mandiId, dateISO)   -> hourly load %
 *   ai.estimateWait(mandi, timeHour, myQtyQuintals) -> minutes
 *   ai.detectPeakHours(mandi)                -> [hours]
 *   ai.detectCongestion(mandiId)             -> { congested, level, reason }
 *   ai.scoreCentre(farmer, mandi, dateISO, timeHour) -> { score, breakdown }
 *   ai.recommend(farmer, prefs) -> [ranked centres]
 */
(function () {
  const RAD = Math.PI / 180;

  function haversine(a, b) {
    const R = 6371; // km
    const dLat = (b.lat - a.lat) * RAD;
    const dLng = (b.lng - a.lng) * RAD;
    const s = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * RAD) * Math.cos(b.lat * RAD) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(s));
  }

  function getMandi(id) {
    const rows = JSON.parse(localStorage.getItem('td.mandis') || '[]');
    return rows.find((r) => r.id === id);
  }
  function getCapacity(mandiId) {
    const rows = JSON.parse(localStorage.getItem('td.centre_capacity') || '[]');
    return rows.find((r) => r.mandi_id === mandiId);
  }
  function getBookings(mandiId, dateISO) {
    const rows = JSON.parse(localStorage.getItem('td.bookings') || '[]');
    return rows.filter((r) => r.mandi_id === mandiId && r.arrival_date === dateISO && r.status !== 'cancelled');
  }
  function getQueue(mandiId) {
    const rows = JSON.parse(localStorage.getItem('td.queue_entries') || '[]');
    return rows.filter((r) => r.mandi_id === mandiId && r.status === 'waiting');
  }

  function predictCentreLoad(mandiId, dateISO) {
    const cap = getCapacity(mandiId);
    const mandi = getMandi(mandiId);
    if (!cap || !mandi) return new Array(24).fill(0);
    const base = cap.hourly_utilisation_pct.slice();
    // Add booking-driven extra load
    const bookings = getBookings(mandiId, dateISO);
    for (const b of bookings) {
      const h = parseInt((b.arrival_time || '10:00').split(':')[0], 10);
      const impact = Math.min(15, (b.quantity || 20) / mandi.capacity_per_day * 100);
      base[h] = Math.min(100, (base[h] || 0) + impact);
      if (base[h + 1] != null) base[h + 1] = Math.min(100, base[h + 1] + impact * 0.4);
    }
    return base;
  }

  function estimateWait(mandi, hour, myQty = 20) {
    const load = predictCentreLoad(mandi.id, new Date().toISOString().slice(0, 10))[hour] || 0;
    // waiting time grows non-linearly with load
    const congestionFactor = load < 60 ? 1 : load < 80 ? 1.6 : load < 92 ? 2.4 : 3.6;
    const base = mandi.avg_processing_min * (mandi.lanes ? (0.7 + 1 / mandi.lanes) : 1);
    const qtyPenalty = (myQty / 50) * 4;
    const live = getQueue(mandi.id).length;
    const liveFactor = 1 + Math.min(1.2, live / (mandi.lanes * 3));
    return Math.round(base * congestionFactor * liveFactor + qtyPenalty);
  }

  function detectPeakHours(mandi) {
    const load = predictCentreLoad(mandi.id, new Date().toISOString().slice(0, 10));
    const sorted = load.map((v, h) => ({ v, h })).sort((a, b) => b.v - a.v);
    return sorted.slice(0, 3).map((x) => x.h).sort();
  }

  function detectCongestion(mandiId) {
    const mandi = getMandi(mandiId);
    if (!mandi) return { congested: false, level: 0, reason: '' };
    const now = new Date();
    const h = now.getHours();
    const dayLoad = predictCentreLoad(mandiId, now.toISOString().slice(0, 10));
    const load = dayLoad[h] || dayLoad[10];
    const live = getQueue(mandiId).length;
    const liveWeight = Math.min(30, live * 2);
    const level = Math.min(100, load + liveWeight - 30);
    let reason = '';
    if (load > 85) reason = 'Peak-hour arrivals concentrated at this centre';
    else if (live > mandi.lanes * 4) reason = 'High live queue relative to processing lanes';
    else if (level > 60) reason = 'Elevated bookings for the selected day';
    return { congested: level > 65, level: Math.round(level), reason: reason || 'Normal operations' };
  }

  function scoreCentre(farmer, mandi, dateISO, hour) {
    const farmerLoc = { lat: farmer.lat || 29.5, lng: farmer.lng || 76.8 };
    const distance = haversine(farmerLoc, { lat: mandi.lat, lng: mandi.lng });
    const wait = estimateWait(mandi, hour, farmer.quantity || 20);
    const dayLoad = predictCentreLoad(mandi.id, dateISO);
    const congestion = dayLoad[hour] || 0;
    const capAvailable = 100 - congestion;
    // Weighted score. Higher = better.
    const wWait = 0.40, wDist = 0.25, wCap = 0.20, wCong = 0.15;
    const sWait = Math.max(0, 100 - wait);              // 100 - min wait
    const sDist = Math.max(0, 100 - distance * 1.4);    // 100 for 0km, ~30 for 50km
    const sCap  = capAvailable;
    const sCong = 100 - congestion;
    const score = wWait * sWait + wDist * sDist + wCap * sCap + wCong * sCong;
    return {
      mandi,
      score: Math.round(score),
      distance: +distance.toFixed(1),
      wait,
      congestion: Math.round(congestion),
      capAvailable: Math.round(capAvailable),
      breakdown: {
        'Waiting time': Math.round(sWait * wWait),
        'Distance': Math.round(sDist * wDist),
        'Capacity available': Math.round(sCap * wCap),
        'Congestion': Math.round(sCong * wCong)
      }
    };
  }

  function recommend(farmer, prefs) {
    const mandis = JSON.parse(localStorage.getItem('td.mandis') || '[]');
    const dateISO = prefs.date || new Date().toISOString().slice(0, 10);
    const hour = parseInt((prefs.time || '10:00').split(':')[0], 10);
    // Filter for commodity match if possible
    const eligible = mandis.filter((m) => !farmer.crop || m.commodities.map((x) => x.toLowerCase()).includes(farmer.crop.toLowerCase()));
    const pool = eligible.length ? eligible : mandis;
    const scored = pool.map((m) => scoreCentre(farmer, m, dateISO, hour));
    scored.sort((a, b) => b.score - a.score);
    // Also propose a better time-slot for the top mandi
    const top = scored[0];
    if (top) {
      const dayLoad = predictCentreLoad(top.mandi.id, dateISO);
      let bestHour = hour;
      let bestWait = estimateWait(top.mandi, hour, farmer.quantity || 20);
      for (let h = 6; h <= 17; h++) {
        const w = estimateWait(top.mandi, h, farmer.quantity || 20);
        if (w < bestWait) { bestWait = w; bestHour = h; }
      }
      top.recommended_hour = bestHour;
      top.recommended_wait = bestWait;
    }
    return scored;
  }

  window.ai = {
    predictCentreLoad,
    estimateWait,
    detectPeakHours,
    detectCongestion,
    scoreCentre,
    recommend,
    haversine
  };
})();
